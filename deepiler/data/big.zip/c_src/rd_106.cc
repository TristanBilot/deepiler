#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=log10(a);
c=(fmax(b,b))/(tan(c));
if(isless(d,b)){
d=fdim(b,c);
a=tan(c);
c=fdim(e,b);
d=asin(b);
}
else{
c=pow(d,e);
e=pow(a,e);
a=asin(d);
b=(fmin(b,b))*(atan2(d,d));
e=log(a);
}
e=(atan2(d,b))*(exp(d));
e=(fmin(e,b))*(fmax(c,a));
c=(log10(c))/(fmax(b,d));
}