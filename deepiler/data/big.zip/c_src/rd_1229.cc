#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=acos(a);
b=fdim(f,e);
c=fmax(d,a);
b=(ceil(e))/(atan(b));
d=pow(a,e);
a=(pow(e,c))/(ceil(b));
d=ceil(c);
d=(exp(b))*(pow(d,a));
}