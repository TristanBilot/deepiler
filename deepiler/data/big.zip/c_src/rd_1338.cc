#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=(ceil(e))*(atan2(c,d));
e=cos(f);
d=exp(d);
f=sqrt(b);
g=exp(c);
while(isgreaterequal(b,e)){
a=(floor(f))-(fmax(e,e));
a=asin(a);
d=(fmin(b,a))*(exp(a));
}
a=acos(a);
g=sin(g);
b=floor(g);
}