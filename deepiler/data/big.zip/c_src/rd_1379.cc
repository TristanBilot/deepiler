#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=exp(a);
b=floor(f);
a=(atan(a))*(pow(b,a));
f=(floor(a))/(fmax(a,e));
f=(fmax(f,c))+(sqrt(c));
e=(fmax(d,d))/(tan(a));
c=log(d);
e=pow(c,e);
}