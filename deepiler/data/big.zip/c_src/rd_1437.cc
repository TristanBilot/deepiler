#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(fdim(c,a))*(fdim(d,c));
d=(sin(d))-(sqrt(e));
while(islessgreater(b,e)){
c=fmin(b,e);
c=atan(d);
a=asin(a);
e=(atan2(d,e))/(fmax(e,b));
c=fmax(a,d);
}
while(islessgreater(a,a)){
b=fmin(e,d);
d=log10(e);
c=fmax(c,e);
}
}