#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=fmin(b,e);
e=(log10(c))*(pow(b,d));
b=tan(c);
if(isgreaterequal(e,e)){
d=fmin(d,d);
a=(fmax(b,a))+(pow(a,a));
e=(log(d))+(tan(a));
a=(log(c))/(fmin(c,a));
b=sqrt(a);
}
while(islessgreater(c,e)){
b=(atan(c))+(cos(a));
e=sqrt(c);
d=(fdim(b,c))/(log10(e));
a=(fmin(a,d))+(tan(c));
b=(tan(b))*(tan(e));
}
}