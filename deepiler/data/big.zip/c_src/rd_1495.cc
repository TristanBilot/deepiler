#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=sqrt(e);
c=asin(a);
c=asin(d);
if(isless(b,a)){
d=fmax(a,d);
c=(atan2(a,b))+(atan2(e,d));
}
else{
b=(cos(b))+(log10(b));
e=(atan(c))+(cos(d));
b=pow(e,d);
}
while(isless(c,c)){
e=log(c);
a=tan(a);
}
}