#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=tan(a);
c=exp(d);
while(islessequal(a,f)){
a=(floor(d))/(atan2(a,e));
b=(asin(e))+(cos(c));
g=atan(b);
a=(fdim(e,c))-(floor(e));
}
while(isgreaterequal(c,e)){
f=exp(c);
c=(fmax(e,a))+(fmax(g,g));
f=(cos(c))/(fmin(b,b));
}
}