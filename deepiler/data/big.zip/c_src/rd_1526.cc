#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=(tan(c))-(atan2(b,d));
d=log10(e);
e=(atan2(e,f))-(sqrt(b));
while(isless(e,a)){
f=(sqrt(d))*(atan2(e,f));
b=fmax(e,e);
b=asin(b);
a=fmin(f,b);
}
b=(cos(c))*(fmax(e,d));
c=(atan2(b,a))/(pow(a,b));
a=atan2(b,e);
e=tan(c);
}