#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=(exp(f))/(tan(e));
a=ceil(e);
f=(fmin(a,b))-(log10(f));
f=cos(c);
e=fmax(c,c);
while(isgreaterequal(f,a)){
d=(tan(a))*(fmax(e,e));
e=(atan2(f,b))/(sin(d));
e=fdim(e,d);
}
if(isgreaterequal(a,b)){
f=(acos(a))*(fmax(a,c));
e=fmax(a,d);
}
}