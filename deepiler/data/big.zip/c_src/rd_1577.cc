#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(exp(e))-(fmin(d,a));
b=(sin(e))+(fmin(b,c));
d=atan2(c,c);
e=floor(c);
e=fmax(e,d);
e=log10(d);
c=(pow(d,a))+(sqrt(c));
e=atan2(b,b);
c=sqrt(b);
a=(pow(b,e))*(fmin(c,e));
c=fdim(c,e);
}