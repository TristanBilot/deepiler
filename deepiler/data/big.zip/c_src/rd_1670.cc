#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=pow(e,b);
c=fdim(d,a);
d=(fdim(f,e))-(ceil(e));
c=(sqrt(a))/(sin(d));
a=ceil(a);
a=(fmax(f,d))-(pow(e,d));
a=(asin(a))-(fdim(e,c));
while(isless(a,d)){
d=sqrt(b);
e=fmin(b,f);
b=(fdim(d,a))*(atan2(a,b));
f=(acos(b))*(atan2(d,f));
}
}