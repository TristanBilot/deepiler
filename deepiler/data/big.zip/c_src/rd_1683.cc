#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=atan2(b,d);
e=fdim(b,d);
f=(tan(b))-(fmax(c,b));
while(isless(a,f)){
b=(fmax(e,e))-(fmin(f,a));
d=atan2(c,a);
f=cos(b);
}
while(islessequal(a,e)){
b=(exp(d))+(acos(c));
a=(sqrt(e))-(asin(c));
c=fdim(f,e);
b=log(d);
c=(fdim(e,f))-(fmax(c,e));
}
}