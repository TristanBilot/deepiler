#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(atan(c))*(atan2(b,c));
e=(asin(a))*(exp(d));
c=(fmax(c,e))-(fdim(e,d));
if(isless(c,c)){
c=fmax(d,c);
c=fmin(c,c);
a=(log10(c))/(atan2(c,c));
}
while(isless(e,c)){
e=fdim(c,d);
a=(fmax(a,e))*(fmax(a,e));
c=(sqrt(c))+(fmax(b,c));
}
}