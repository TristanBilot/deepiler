#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=(asin(d))-(pow(c,c));
f=atan2(b,e);
d=(cos(e))/(fmin(b,a));
a=fdim(f,a);
d=pow(c,b);
while(isless(d,a)){
e=ceil(b);
f=(fmax(a,a))-(fmin(f,c));
f=fmin(d,d);
c=atan2(e,c);
c=fmax(f,a);
}
c=sqrt(d);
d=ceil(c);
e=(fdim(e,b))+(atan2(f,d));
d=(fmin(c,d))-(fmin(e,c));
}