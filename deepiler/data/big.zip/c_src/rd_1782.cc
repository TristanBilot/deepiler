#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(log10(c))*(fmax(e,b));
b=ceil(f);
d=(fdim(f,e))+(fmax(e,c));
while(isless(d,a)){
a=fmin(f,b);
d=log10(b);
e=asin(e);
}
c=asin(a);
c=(atan2(b,d))+(fmax(f,f));
e=(floor(c))/(tan(a));
d=(acos(a))-(log(b));
}