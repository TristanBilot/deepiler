#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=sin(c);
e=(fdim(f,e))-(atan2(d,e));
d=sin(e);
b=(log(f))/(cos(f));
while(islessequal(f,c)){
e=(acos(d))/(sin(c));
d=(fdim(f,f))/(exp(b));
b=(tan(d))*(fdim(e,e));
c=(pow(f,f))/(fmax(c,b));
a=(pow(f,e))+(atan2(e,f));
}
while(isless(d,e)){
a=(pow(b,e))*(fdim(a,a));
a=(acos(a))/(sqrt(d));
f=fdim(f,b);
}
}