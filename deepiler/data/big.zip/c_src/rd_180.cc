#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
e=atan(e);
e=(fmin(c,g))/(asin(g));
while(isgreaterequal(e,b)){
e=ceil(f);
a=acos(d);
c=(fmax(c,g))/(log10(c));
d=(fmin(e,e))/(log10(d));
f=atan(c);
}
while(islessequal(f,e)){
g=(pow(f,f))+(atan2(e,d));
f=fdim(a,e);
d=(fdim(d,c))*(cos(a));
f=sqrt(c);
}
}