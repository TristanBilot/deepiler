#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=(floor(d))*(log(e));
c=(sin(d))/(sqrt(e));
a=(pow(f,h))*(ceil(g));
d=pow(b,c);
e=(sin(d))+(ceil(b));
g=(acos(g))*(atan2(f,b));
b=acos(e);
b=(fmax(d,h))-(atan(a));
f=acos(d);
while(islessgreater(g,g)){
b=fmax(b,f);
d=sqrt(g);
e=pow(c,g);
c=(fmax(g,d))-(tan(e));
c=sqrt(e);
}
}