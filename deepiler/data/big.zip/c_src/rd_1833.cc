#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=fdim(e,a);
c=fmax(d,c);
f=tan(e);
h=tan(c);
if(isless(h,f)){
d=fmin(b,g);
a=(fmin(c,a))+(cos(c));
g=(log(b))/(exp(h));
f=(pow(f,g))*(log(a));
b=(fmin(g,e))/(pow(f,d));
}
while(islessequal(e,c)){
b=(atan2(f,g))/(pow(h,e));
f=fmin(d,e);
e=(fmin(a,a))+(tan(h));
g=(sqrt(a))+(floor(d));
}
}