#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=(asin(d))/(ceil(c));
f=atan2(f,f);
c=(asin(d))+(fmax(f,c));
h=log10(c);
a=(log(a))*(fdim(b,g));
if(isless(f,g)){
g=sin(e);
b=(fmin(a,h))*(atan(a));
b=atan(h);
}
else{
c=log(c);
f=sqrt(g);
e=tan(e);
}
while(isless(f,a)){
c=pow(b,e);
f=fmax(e,b);
f=pow(f,e);
}
}