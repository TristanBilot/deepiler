#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(sqrt(e))*(tan(d));
b=(sqrt(d))*(exp(a));
a=fmin(b,c);
b=(pow(e,a))-(log10(a));
e=fdim(e,e);
c=log10(a);
if(isless(e,b)){
e=(ceil(d))+(atan(e));
d=fmax(a,b);
e=atan2(e,e);
}
}