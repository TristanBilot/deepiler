#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(fmin(e,d))+(fmax(c,d));
a=sqrt(c);
b=fmin(b,c);
b=fdim(a,c);
b=(acos(d))-(cos(e));
while(islessgreater(a,d)){
e=(fmin(c,b))*(fdim(d,c));
d=(fmin(e,d))*(pow(e,a));
d=tan(a);
b=pow(c,d);
e=(fdim(e,d))*(fmin(d,a));
}
a=(log(a))-(fmax(d,a));
a=(atan(c))/(fmax(d,e));
}