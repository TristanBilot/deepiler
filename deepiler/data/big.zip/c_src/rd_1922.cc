#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=atan2(b,e);
f=log(c);
h=fmax(a,b);
d=floor(f);
if(isless(d,c)){
h=floor(b);
c=(fmin(b,h))/(tan(f));
g=ceil(f);
}
if(isless(f,g)){
b=fmax(g,f);
b=(fdim(c,c))+(cos(g));
d=fmin(a,f);
a=atan2(g,f);
a=cos(h);
}
}