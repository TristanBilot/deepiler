#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
a=fdim(a,b);
f=(pow(c,a))*(acos(e));
a=floor(d);
h=(sqrt(e))+(log(d));
h=sin(b);
e=fdim(f,b);
c=(atan(a))/(fdim(c,d));
d=pow(b,g);
if(isgreaterequal(g,h)){
g=fdim(f,a);
e=tan(a);
e=(cos(d))*(pow(h,e));
e=acos(g);
}
}