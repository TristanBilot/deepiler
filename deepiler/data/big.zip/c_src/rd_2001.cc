#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(log10(b))*(fmin(d,d));
c=sqrt(d);
c=(fdim(a,f))-(log(d));
e=pow(e,b);
while(isless(f,f)){
b=ceil(c);
c=pow(d,e);
d=exp(c);
e=(sqrt(a))*(cos(d));
}
while(isless(c,c)){
a=(log10(e))/(fmin(d,c));
f=cos(a);
f=(atan(a))*(sin(a));
a=log10(b);
}
}