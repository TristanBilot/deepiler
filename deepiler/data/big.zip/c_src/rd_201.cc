#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
c=fmax(d,d);
c=(fmax(c,f))+(pow(g,h));
h=fmax(d,g);
a=fdim(a,d);
c=ceil(h);
e=tan(e);
a=(pow(d,a))*(exp(g));
b=(tan(a))/(fmin(a,d));
f=(fmax(d,h))*(exp(h));
b=(atan(g))*(fmax(e,h));
e=pow(b,e);
a=log10(b);
}