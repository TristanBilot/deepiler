#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=(sin(b))*(log10(h));
d=(atan2(f,c))/(fmax(g,a));
h=(atan(a))+(sin(c));
d=acos(f);
h=fmax(e,c);
while(isless(a,e)){
g=(ceil(c))*(log(d));
c=(cos(b))-(atan(h));
a=(atan2(d,e))/(fdim(b,h));
g=(atan2(e,g))+(pow(d,c));
e=log10(h);
}
b=fdim(d,b);
f=(atan2(b,e))/(fmax(g,a));
d=fdim(e,a);
}