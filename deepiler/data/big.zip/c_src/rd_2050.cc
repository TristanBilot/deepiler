#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(atan(e))*(pow(c,e));
b=asin(a);
e=(fmax(a,d))-(pow(a,e));
c=atan(a);
b=atan2(d,d);
c=(log10(e))-(log(a));
d=sqrt(e);
if(islessgreater(e,b)){
b=log(b);
a=exp(a);
}
else{
d=sin(e);
e=atan(b);
e=(atan2(c,e))/(asin(e));
}
}