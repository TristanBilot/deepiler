#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(atan(e))*(atan2(c,e));
e=(log10(a))*(log10(e));
b=(fdim(d,d))*(pow(b,d));
d=log(d);
while(isgreaterequal(d,e)){
b=cos(e);
e=(fmax(c,a))-(asin(c));
}
e=exp(a);
d=fmin(c,e);
a=(tan(a))-(acos(a));
a=(fmin(a,a))-(fmax(e,d));
}