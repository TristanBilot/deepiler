#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=log(d);
c=atan2(e,d);
a=fmax(b,d);
if(islessequal(a,e)){
c=pow(e,a);
d=(atan2(d,c))*(pow(a,e));
}
else{
d=acos(c);
e=ceil(d);
}
while(islessgreater(c,e)){
c=exp(d);
a=(pow(e,c))-(acos(a));
e=(cos(d))-(log10(d));
d=fdim(b,c);
}
}