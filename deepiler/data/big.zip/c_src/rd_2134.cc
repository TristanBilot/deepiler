#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
h=(fdim(c,a))+(fmax(e,a));
e=(tan(a))*(fdim(g,a));
c=atan2(e,g);
a=ceil(b);
a=floor(c);
e=atan2(e,d);
e=(log(c))-(cos(g));
h=(fdim(f,e))-(log10(e));
g=(atan2(a,a))*(floor(h));
while(islessequal(g,b)){
e=fmax(g,h);
e=ceil(b);
e=atan2(f,c);
e=(fmin(d,a))*(asin(g));
}
}