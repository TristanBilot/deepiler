#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=pow(c,e);
a=(acos(c))+(atan2(c,e));
f=log(d);
c=(atan2(d,f))*(fdim(c,d));
e=pow(a,c);
while(isless(b,c)){
c=(fmin(e,d))/(atan2(f,a));
d=(pow(d,f))-(ceil(f));
e=pow(d,c);
e=(fmax(c,f))-(cos(e));
a=atan2(a,f);
}
c=fmin(f,f);
a=(fdim(c,e))/(asin(b));
b=(fdim(d,b))/(exp(d));
a=cos(d);
e=(acos(d))/(log10(b));
}