#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=acos(b);
c=(floor(b))*(log10(d));
d=(exp(b))*(fmin(d,d));
if(isless(f,d)){
c=asin(c);
a=(pow(b,d))+(tan(b));
c=pow(d,a);
e=pow(a,c);
}
else{
d=cos(d);
d=floor(f);
}
if(islessequal(f,e)){
a=atan2(f,c);
f=ceil(b);
e=sqrt(c);
f=(log10(b))+(tan(a));
c=(fmax(b,f))*(pow(a,d));
}
else{
f=(atan2(d,a))*(atan2(f,a));
c=(pow(e,c))/(fmax(e,a));
f=(log10(a))+(fmax(f,d));
f=pow(a,f);
}
}