#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
b=atan2(d,d);
h=(fmin(a,e))/(atan(e));
a=cos(f);
f=(fdim(b,c))-(tan(h));
h=fdim(f,b);
f=fdim(c,e);
c=fmin(b,e);
b=(pow(g,d))/(cos(c));
c=(fdim(h,a))/(log10(g));
d=floor(f);
}