#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=fmax(b,b);
b=(pow(e,a))+(fdim(b,e));
c=atan2(c,e);
c=fdim(e,b);
e=cos(c);
if(islessequal(e,b)){
e=fmin(e,e);
e=exp(c);
}
a=tan(b);
d=(atan2(d,b))/(pow(c,d));
}