#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(ceil(b))*(sqrt(f));
c=(pow(b,c))/(exp(d));
b=(pow(b,b))-(log(d));
b=(fdim(b,d))-(pow(c,d));
e=(log(c))-(sin(b));
b=pow(a,e);
d=(cos(e))-(exp(c));
c=log(d);
c=pow(a,f);
f=(sin(d))/(exp(e));
a=asin(f);
b=acos(a);
e=exp(b);
}