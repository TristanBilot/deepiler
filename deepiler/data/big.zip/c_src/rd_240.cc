#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(log10(c))*(log(b));
c=(log(a))/(fmax(b,c));
d=(atan(c))/(ceil(e));
d=exp(d);
a=(log10(e))-(fdim(c,d));
while(islessgreater(a,a)){
b=log10(a);
c=pow(c,c);
e=(fmax(d,c))/(fdim(a,a));
d=fdim(b,d);
}
while(islessgreater(d,b)){
a=cos(e);
c=fmin(d,c);
}
}