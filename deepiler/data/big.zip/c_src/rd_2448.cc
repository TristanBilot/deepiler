#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=fmax(c,e);
f=fmax(g,d);
c=(atan(a))*(fmax(d,b));
f=fdim(g,d);
if(islessequal(e,b)){
a=atan2(d,d);
d=log10(c);
f=fdim(b,d);
f=fmax(e,g);
}
else{
e=(pow(d,e))+(log10(a));
e=(asin(d))*(fmax(e,b));
a=(sqrt(c))*(cos(c));
f=(floor(b))-(sqrt(e));
}
}