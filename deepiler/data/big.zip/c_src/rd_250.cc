#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(fmax(d,c))-(cos(d));
d=floor(e);
while(isgreaterequal(e,b)){
b=fmin(a,e);
c=pow(c,a);
b=fmin(d,e);
d=(atan2(a,b))*(atan2(d,e));
b=acos(e);
}
if(islessgreater(c,e)){
b=(fdim(d,d))-(atan2(b,e));
a=(floor(c))*(fmax(c,d));
a=atan2(c,b);
}
else{
a=(fmax(d,a))-(tan(d));
d=(log10(c))*(asin(b));
d=fmax(b,b);
}
}