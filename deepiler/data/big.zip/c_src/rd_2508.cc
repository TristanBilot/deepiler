#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=(fmax(g,b))*(cos(f));
d=(log10(f))/(fmax(b,d));
g=floor(a);
if(islessgreater(d,g)){
e=(pow(f,c))*(fmax(d,c));
b=(fmin(a,e))/(atan2(a,a));
b=(exp(d))+(log10(a));
g=fmin(b,a);
d=(asin(c))*(fmin(e,g));
}
else{
c=tan(f);
g=(fmax(d,g))/(exp(c));
}
e=(acos(b))+(log(f));
a=fdim(c,e);
f=(atan2(a,b))*(atan(g));
}