#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
b=acos(g);
f=fmin(g,d);
e=(sin(g))*(fmax(b,f));
h=fmin(d,c);
g=(pow(f,g))-(fmin(h,c));
while(isgreaterequal(a,g)){
a=fdim(e,d);
c=atan(a);
f=floor(d);
}
if(islessequal(a,b)){
b=log(a);
a=(atan(e))/(fdim(g,g));
b=(sqrt(c))+(fmax(f,c));
d=(fmax(c,g))-(fmin(f,e));
e=ceil(h);
}
else{
d=atan2(f,g);
g=(exp(h))-(ceil(d));
e=atan2(g,g);
}
}