#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=fdim(c,e);
a=fmax(c,c);
a=ceil(c);
while(isgreaterequal(c,c)){
b=(tan(a))/(ceil(e));
a=fmax(b,b);
b=(sin(e))-(pow(e,e));
}
while(islessequal(e,d)){
b=sqrt(b);
a=fmax(b,e);
b=(log(b))-(cos(d));
}
}