#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=atan2(g,c);
f=fmin(b,g);
g=(atan2(e,c))+(atan2(g,f));
while(isgreaterequal(d,c)){
e=(acos(e))-(pow(e,d));
c=fmin(e,a);
}
while(islessequal(c,d)){
d=(fmin(d,d))-(cos(c));
a=pow(d,g);
}
}