#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=(log(c))-(fmax(a,c));
c=(sin(c))-(log(f));
e=log(c);
a=fmin(e,f);
while(islessequal(b,b)){
f=fdim(f,a);
b=(fdim(f,e))-(acos(d));
b=atan(e);
}
if(islessequal(f,b)){
f=acos(d);
f=sqrt(a);
e=fdim(b,f);
d=(fmax(f,e))-(fdim(d,b));
}
else{
b=(acos(f))-(fmax(d,d));
f=ceil(c);
e=tan(a);
}
}