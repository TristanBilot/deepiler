#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(atan2(e,e))/(fmax(a,f));
c=floor(e);
c=(fmax(a,b))/(floor(c));
if(islessequal(d,e)){
e=fmax(f,c);
f=(pow(f,d))-(atan2(c,f));
d=ceil(d);
d=(atan(b))*(fmax(b,f));
e=cos(f);
}
else{
e=fdim(e,f);
b=atan2(f,a);
e=(sin(c))*(fdim(b,e));
b=(fmax(a,e))-(atan(a));
}
d=pow(c,f);
b=atan2(a,a);
e=floor(c);
c=(cos(a))*(fmin(a,a));
}