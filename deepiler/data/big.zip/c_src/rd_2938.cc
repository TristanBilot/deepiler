#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(acos(c))+(atan(a));
a=(pow(c,e))-(fmin(b,d));
if(isgreaterequal(b,a)){
a=(asin(e))/(fmax(d,a));
d=tan(b);
}
else{
b=log10(d);
a=fdim(a,d);
}
while(isgreaterequal(c,d)){
a=pow(e,d);
d=fmax(c,b);
}
}