#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
b=(fmax(a,d))+(fmax(c,e));
a=(log10(a))/(pow(b,c));
e=fmax(h,c);
d=sin(h);
g=pow(a,d);
b=fmax(f,c);
e=sqrt(f);
b=(log(c))-(log10(e));
g=sqrt(d);
if(isless(b,e)){
h=(exp(g))/(cos(c));
f=fdim(f,h);
a=fdim(f,c);
f=(fdim(e,f))*(atan2(d,d));
e=(log(f))*(fmax(h,a));
}
else{
a=(atan(g))/(fmin(f,g));
f=(sqrt(d))/(log(c));
b=(log10(a))/(pow(e,h));
d=(sin(f))+(log10(f));
g=pow(h,f);
}
}