#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(exp(d))*(atan2(b,c));
a=log10(e);
b=fmin(d,c);
e=ceil(a);
if(islessgreater(d,d)){
c=pow(e,e);
c=fmax(b,e);
a=fmin(e,b);
b=exp(a);
}
else{
c=fdim(c,c);
d=atan2(b,c);
d=sin(d);
d=(ceil(e))-(pow(e,c));
}
while(islessgreater(c,b)){
e=atan(a);
e=sin(e);
e=(atan(c))+(atan2(b,e));
}
}