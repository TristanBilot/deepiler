#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=atan2(a,a);
f=(log10(a))/(fmax(a,c));
a=(exp(b))/(pow(b,f));
if(isless(c,d)){
c=log10(d);
d=(fmin(f,d))+(sin(a));
d=acos(a);
b=pow(a,e);
}
while(isgreaterequal(b,e)){
d=log(b);
e=fmax(a,e);
c=(log(f))/(acos(f));
b=sqrt(a);
}
}