#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=sin(b);
e=tan(f);
b=fmax(b,e);
while(isgreaterequal(d,e)){
b=tan(f);
f=pow(b,b);
d=asin(e);
d=(exp(b))+(pow(a,b));
a=pow(e,c);
}
while(islessgreater(e,a)){
c=atan2(a,c);
d=(fmax(a,c))/(fmax(a,a));
c=(sin(a))+(atan2(a,a));
a=fmax(b,c);
c=log10(c);
}
}