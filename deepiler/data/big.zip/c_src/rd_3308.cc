#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=acos(b);
b=(sin(a))*(exp(a));
e=(sin(e))+(exp(c));
e=pow(d,b);
if(islessgreater(c,d)){
c=(exp(b))/(pow(a,c));
c=(log(e))-(fmin(c,b));
}
else{
d=(atan2(a,c))-(exp(b));
c=(atan2(b,e))/(fmin(e,a));
d=log10(a);
a=(fmin(b,b))/(sin(d));
}
if(isless(e,e)){
a=atan(d);
d=(fmax(b,e))+(log10(d));
}
else{
d=(pow(a,a))*(fmin(b,c));
d=(ceil(c))/(pow(e,d));
a=floor(e);
e=(floor(b))/(pow(b,b));
}
}