#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
a=ceil(c);
h=atan2(g,e);
b=(tan(e))/(fdim(a,c));
g=fdim(f,b);
d=(sqrt(a))*(sin(e));
h=fdim(h,b);
f=(acos(e))*(log10(f));
d=(ceil(b))/(pow(f,a));
}