#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=pow(c,b);
g=(fdim(c,e))*(pow(c,a));
f=(exp(b))*(atan2(b,c));
a=(fmin(e,c))*(fdim(e,b));
while(islessequal(e,c)){
b=(fmin(a,a))+(sqrt(a));
c=fdim(f,a);
b=(log10(e))-(fmax(b,d));
b=cos(c);
b=sqrt(g);
}
while(isless(d,a)){
e=(exp(e))/(fmax(d,e));
f=pow(b,e);
a=fmax(a,a);
}
}