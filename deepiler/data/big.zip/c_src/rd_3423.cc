#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
c=(fmax(a,d))/(fdim(a,g));
e=log10(a);
h=cos(d);
a=pow(g,g);
h=(pow(a,a))/(ceil(f));
b=asin(a);
d=(atan2(d,b))*(fmin(e,d));
b=cos(h);
b=(atan2(g,c))-(exp(a));
b=(tan(e))-(sin(b));
}