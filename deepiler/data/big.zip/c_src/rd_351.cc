#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(fmin(b,c))*(sin(d));
b=(log10(c))/(ceil(a));
a=(fmax(a,a))/(cos(e));
b=(sin(a))-(pow(d,e));
c=fdim(c,c);
if(islessgreater(c,a)){
b=ceil(b);
e=tan(d);
}
else{
d=fdim(a,b);
b=(exp(b))+(log(e));
b=pow(e,b);
a=atan(c);
}
if(isless(b,b)){
e=atan(c);
a=tan(c);
a=pow(a,a);
a=(cos(c))*(log10(a));
c=sqrt(a);
}
else{
e=(fmax(d,e))+(pow(c,a));
d=(atan(e))+(tan(d));
}
}