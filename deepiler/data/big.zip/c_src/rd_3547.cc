#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=atan2(e,c);
b=(log(f))*(atan(e));
e=(fmax(a,b))/(atan2(d,f));
if(islessequal(d,c)){
f=(atan(f))/(tan(e));
e=(fmin(d,b))*(fmax(c,c));
d=(fmin(c,d))/(asin(d));
d=acos(a);
}
e=(fmax(b,d))/(atan(d));
d=sin(a);
f=(acos(c))/(pow(d,c));
c=floor(a);
c=fmin(c,e);
}