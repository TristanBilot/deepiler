#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=ceil(b);
a=cos(e);
c=(cos(d))*(floor(e));
e=(fdim(d,g))+(fdim(g,b));
c=fmin(b,e);
while(isgreaterequal(b,a)){
e=atan2(f,f);
f=(cos(e))/(ceil(g));
c=cos(d);
b=(sin(b))+(pow(g,c));
}
}