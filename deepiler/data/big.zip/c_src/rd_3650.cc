#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=cos(b);
a=(fdim(a,e))-(atan2(b,a));
a=(fmin(b,e))-(fdim(a,b));
b=(exp(c))*(fmax(d,b));
d=(sqrt(e))+(atan2(e,c));
if(islessequal(a,a)){
d=atan2(a,e);
e=(asin(d))*(acos(e));
a=(fdim(e,c))/(atan2(a,d));
}
if(islessgreater(a,a)){
a=atan(a);
a=(floor(c))+(sqrt(c));
e=(pow(e,c))*(atan(a));
c=(atan2(c,a))-(exp(b));
d=ceil(e);
}
}