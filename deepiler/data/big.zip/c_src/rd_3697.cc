#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
c=fmax(c,d);
f=(log(h))-(log10(h));
b=(tan(d))+(asin(a));
d=fdim(c,e);
b=fmax(f,g);
e=(fmax(a,c))+(fmin(h,h));
b=fdim(a,c);
b=(cos(h))*(cos(h));
a=(fdim(e,b))-(atan2(b,a));
a=sqrt(f);
if(isgreaterequal(c,f)){
b=log(d);
a=log10(e);
a=(sin(g))*(fmax(b,d));
g=(exp(f))-(cos(b));
}
}