#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=(fdim(a,g))+(pow(a,f));
d=fmax(b,e);
if(islessequal(a,a)){
b=(cos(e))+(fdim(f,c));
d=(atan(g))*(fmax(b,g));
b=(atan2(a,b))*(asin(a));
}
g=atan2(g,a);
e=(cos(c))*(fmax(f,d));
g=(atan2(e,d))/(exp(a));
d=(floor(d))+(fmax(d,e));
b=(fmin(a,a))*(fmax(c,c));
}