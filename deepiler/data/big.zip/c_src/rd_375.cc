#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=(sin(d))*(pow(b,b));
c=(fdim(f,f))*(fmin(c,b));
c=log10(c);
f=(floor(e))+(log10(b));
c=(fmax(c,e))/(fmin(f,d));
b=fmax(d,c);
f=(fdim(a,f))*(log10(d));
e=(pow(b,e))/(pow(c,e));
f=log10(d);
g=fmax(a,e);
a=(log(f))*(sin(b));
}