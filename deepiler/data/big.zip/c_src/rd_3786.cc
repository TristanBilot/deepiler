#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=(atan(b))+(fmax(d,d));
a=log10(f);
while(isgreaterequal(c,a)){
d=(fmax(e,d))/(sin(d));
c=(pow(d,b))+(sqrt(b));
f=(fmax(a,e))-(pow(b,e));
e=fmax(b,a);
}
e=(pow(a,c))+(tan(b));
d=log(c);
a=asin(a);
e=(floor(c))+(log10(f));
}