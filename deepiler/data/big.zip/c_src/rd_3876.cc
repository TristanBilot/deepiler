#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=(fdim(c,e))+(cos(f));
e=fdim(b,d);
b=(tan(e))+(sqrt(e));
d=(atan2(b,c))+(log10(a));
b=atan2(f,f);
if(islessgreater(a,c)){
d=(fmin(a,b))+(exp(b));
c=(tan(c))/(log10(d));
f=fmin(d,e);
d=(fmin(d,e))*(ceil(b));
a=ceil(c);
}
}