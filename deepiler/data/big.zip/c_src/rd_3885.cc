#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(acos(c))-(tan(b));
a=ceil(b);
b=(sqrt(c))*(atan(e));
d=(pow(e,d))-(fdim(a,d));
a=(fmax(a,c))+(fmax(b,e));
c=acos(a);
a=log(e);
a=atan(a);
a=floor(c);
c=fmax(c,d);
c=fmax(a,e);
d=fmax(a,c);
a=fmax(d,a);
}