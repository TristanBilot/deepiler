#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=(atan2(g,c))/(floor(b));
c=tan(g);
c=(fdim(f,a))-(exp(a));
c=(floor(e))/(pow(a,c));
a=(log(c))*(atan2(a,f));
f=(fmin(d,d))-(fmax(g,b));
g=(fmin(c,d))+(floor(e));
if(isless(b,a)){
d=sqrt(b);
e=(fmax(g,e))*(log(f));
}
else{
d=fmax(c,b);
g=fmin(c,e);
}
}