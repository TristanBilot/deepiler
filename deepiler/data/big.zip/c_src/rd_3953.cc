#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(atan2(a,a))*(atan2(b,c));
d=fmax(e,e);
a=atan(a);
b=(fmin(d,e))+(fmax(b,c));
e=(atan2(b,e))*(log(d));
while(isgreaterequal(e,b)){
d=fmax(e,a);
a=tan(a);
a=(log10(b))+(exp(a));
}
if(islessgreater(e,b)){
a=(pow(a,c))/(sqrt(d));
a=(log10(a))*(log10(e));
b=(pow(c,d))-(atan2(c,e));
b=(fmin(e,a))*(fmax(c,b));
c=(tan(d))/(fdim(e,a));
}
}