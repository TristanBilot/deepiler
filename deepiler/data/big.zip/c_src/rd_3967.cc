#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=(sqrt(d))/(log10(d));
b=(cos(c))/(log(d));
b=fmax(a,d);
while(isgreaterequal(c,e)){
a=fdim(d,e);
b=sin(b);
d=atan2(e,c);
}
while(islessgreater(c,d)){
b=cos(b);
c=(exp(e))/(fmin(a,e));
b=(fmax(a,a))*(cos(e));
}
}