#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
a=asin(c);
f=(pow(e,a))*(fmin(f,d));
d=fdim(d,g);
g=floor(g);
while(islessequal(g,c)){
g=ceil(g);
e=(fmax(b,b))/(atan2(b,c));
}
e=(pow(e,g))-(cos(d));
e=(fmax(e,b))+(fmax(d,b));
}