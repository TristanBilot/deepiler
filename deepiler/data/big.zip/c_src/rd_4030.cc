#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=(log10(f))*(acos(a));
b=exp(a);
d=(tan(a))-(cos(d));
if(islessequal(c,e)){
a=(fmax(d,d))+(log(c));
a=tan(e);
}
else{
e=floor(d);
f=atan2(e,e);
f=acos(f);
b=(atan(c))-(fmin(b,f));
}
if(islessequal(f,e)){
b=pow(b,c);
e=(atan(c))-(pow(b,c));
f=(sin(a))/(ceil(b));
}
else{
f=fmax(f,a);
c=(fmax(d,d))*(fmin(d,a));
a=(acos(e))/(fmin(b,a));
}
}