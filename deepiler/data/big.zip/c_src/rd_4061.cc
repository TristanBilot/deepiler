#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=log10(g);
f=atan2(h,g);
c=(exp(a))-(tan(f));
g=sin(g);
e=sqrt(h);
if(islessgreater(a,b)){
e=acos(f);
h=(atan2(h,c))*(ceil(g));
f=(ceil(g))+(atan2(g,c));
b=acos(c);
a=fmax(c,f);
}
else{
h=cos(c);
e=(sqrt(e))+(pow(a,a));
e=(fdim(h,d))/(pow(a,g));
}
if(islessequal(b,c)){
c=fmin(c,h);
f=log10(c);
f=(atan(g))/(pow(b,c));
b=floor(f);
h=(atan2(b,g))-(sqrt(d));
}
else{
e=asin(h);
e=atan2(a,d);
f=(atan(g))/(fmax(f,e));
e=(ceil(b))/(pow(e,g));
}
}