#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(exp(c))/(pow(d,c));
a=fdim(a,a);
e=(acos(e))-(log(d));
c=(ceil(a))+(log10(b));
c=fdim(b,e);
d=pow(d,a);
e=fdim(e,e);
if(isless(b,d)){
d=ceil(c);
a=fmin(c,b);
}
else{
a=(ceil(d))/(fdim(a,a));
a=(fmin(d,d))-(atan2(c,d));
e=(exp(c))+(ceil(a));
}
}