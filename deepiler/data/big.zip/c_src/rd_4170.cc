#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=(atan(a))/(sqrt(d));
b=atan2(a,f);
a=fmin(d,b);
b=fmax(d,c);
while(isgreaterequal(e,a)){
e=fmin(b,b);
f=(fdim(a,d))+(atan2(d,a));
f=(fmax(c,f))-(pow(e,f));
e=fmax(f,b);
f=(pow(b,e))-(exp(d));
}
while(islessequal(f,c)){
e=atan(b);
f=ceil(c);
c=(fdim(c,a))+(fmax(f,e));
d=(pow(c,a))+(floor(d));
a=fmin(d,a);
}
}