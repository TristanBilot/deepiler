#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
a=(atan2(c,g))-(sqrt(a));
d=fmin(a,g);
a=(ceil(d))+(atan2(b,e));
h=exp(h);
while(islessequal(a,b)){
h=fdim(d,f);
f=floor(d);
h=(log(e))+(ceil(a));
c=(floor(d))+(atan2(e,a));
}
if(isgreaterequal(e,d)){
b=(log10(g))*(atan2(d,g));
b=(fmin(b,e))*(log(h));
c=log(d);
h=(fmin(b,b))+(atan2(g,g));
h=(acos(f))*(fmax(d,e));
}
else{
h=fmin(h,g);
d=(floor(b))*(atan2(g,f));
}
}