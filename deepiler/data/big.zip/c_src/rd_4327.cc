#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=(tan(b))+(fdim(g,d));
b=cos(a);
c=fdim(b,e);
e=(fmax(c,c))/(exp(c));
a=(cos(d))-(fdim(b,b));
a=(sqrt(b))/(fmin(d,g));
c=fmin(c,e);
f=fmax(g,d);
c=(fmax(a,f))/(fmin(a,d));
}