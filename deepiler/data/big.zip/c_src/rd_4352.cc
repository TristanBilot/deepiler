#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=(fmax(c,h))-(fmin(e,f));
a=(fdim(h,a))*(acos(f));
f=atan2(a,d);
g=(cos(d))-(fmax(e,e));
b=atan2(a,a);
b=exp(e);
h=fmax(d,h);
c=exp(c);
e=(pow(a,a))+(fdim(c,a));
}