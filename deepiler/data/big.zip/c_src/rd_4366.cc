#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(log10(c))-(atan2(a,d));
a=exp(b);
c=fmax(c,b);
d=atan2(e,e);
e=fmax(e,b);
b=(fdim(d,b))+(cos(d));
b=pow(a,e);
e=(pow(a,b))/(log10(e));
if(islessgreater(a,a)){
d=exp(e);
b=(floor(e))*(fmin(a,d));
a=(fmin(a,a))-(asin(a));
b=fmax(b,c);
b=acos(c);
}
else{
d=(pow(b,d))-(fmax(b,c));
c=(atan(c))/(fmin(e,b));
c=(tan(b))+(pow(d,e));
e=fmax(c,a);
}
}