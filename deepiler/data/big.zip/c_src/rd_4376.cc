#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=fmax(b,a);
c=fmax(a,a);
e=(cos(a))/(fdim(a,a));
while(isgreaterequal(c,b)){
b=(sin(c))-(exp(e));
b=(asin(d))*(floor(d));
d=log10(b);
e=fmax(a,e);
c=(fmin(a,e))+(pow(c,a));
}
if(islessequal(e,d)){
a=(exp(a))-(fdim(c,e));
c=(pow(c,c))/(ceil(d));
}
}