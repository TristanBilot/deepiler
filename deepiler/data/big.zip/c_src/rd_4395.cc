#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(log10(d))/(fdim(c,c));
b=(fmax(a,e))-(log10(a));
e=(pow(d,b))-(fmin(b,b));
e=tan(a);
while(isless(a,d)){
b=fmin(d,e);
d=asin(e);
}
if(isgreaterequal(c,c)){
e=(exp(b))/(sin(e));
b=sqrt(b);
a=fdim(b,a);
d=(ceil(a))/(tan(b));
}
}