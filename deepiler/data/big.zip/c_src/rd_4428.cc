#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=tan(a);
e=(asin(c))*(pow(b,b));
b=(fmax(e,a))-(sin(e));
while(isless(c,d)){
e=floor(e);
c=log10(b);
c=atan(d);
e=(fmax(a,a))*(log(e));
a=acos(b);
}
e=atan2(a,a);
b=(pow(c,e))+(exp(a));
}