#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=(cos(a))*(exp(b));
c=(cos(e))/(log10(d));
c=(sin(b))/(fmin(b,f));
a=fmax(f,f);
a=(fmax(f,e))/(tan(f));
while(islessgreater(c,d)){
c=tan(d);
d=atan2(a,a);
a=(asin(c))/(pow(e,e));
f=fmin(c,f);
}
if(isgreaterequal(a,a)){
d=(sqrt(b))-(asin(f));
c=(atan(e))/(fmin(f,a));
a=ceil(f);
}
}