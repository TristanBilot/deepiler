#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=log(c);
c=(tan(e))*(sin(c));
e=(sqrt(a))+(fmin(b,e));
a=(atan2(d,c))-(fmin(c,e));
while(isgreaterequal(e,a)){
e=(atan2(a,a))+(ceil(e));
b=fmin(b,d);
d=(atan2(a,e))+(fmax(d,d));
b=fmax(c,a);
}
}