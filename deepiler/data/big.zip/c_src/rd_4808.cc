#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(atan(e))/(cos(c));
a=ceil(a);
e=atan2(d,d);
c=(pow(c,c))+(sin(e));
while(islessequal(a,d)){
b=exp(b);
d=floor(c);
b=fmax(c,b);
}
if(isless(b,c)){
d=atan2(d,e);
b=fmin(c,a);
}
}