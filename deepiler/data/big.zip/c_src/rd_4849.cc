#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=fmin(a,a);
a=(fmax(d,c))*(pow(c,d));
a=atan2(e,b);
e=pow(b,b);
d=floor(c);
e=(pow(e,e))-(fmax(e,b));
b=log(a);
e=sqrt(b);
b=fmax(d,d);
c=ceil(e);
b=cos(a);
d=(atan2(c,b))*(tan(e));
}