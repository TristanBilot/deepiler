#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=pow(d,d);
c=(sqrt(c))+(tan(d));
a=fmax(e,b);
b=floor(e);
if(isless(e,f)){
b=(asin(a))*(log(c));
a=atan2(f,e);
f=atan(c);
c=pow(a,f);
d=fmin(d,e);
}
c=exp(e);
d=(fmax(d,c))/(fmin(e,e));
d=fmin(e,c);
c=log(a);
}