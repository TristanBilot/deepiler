#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(fmin(b,a))-(ceil(d));
a=(fmin(c,c))+(exp(b));
b=(exp(b))*(floor(a));
b=exp(e);
c=fmin(c,d);
if(islessgreater(d,b)){
d=pow(e,e);
a=acos(e);
e=floor(b);
}
a=ceil(e);
c=(ceil(a))-(fmin(a,a));
b=atan2(a,d);
d=asin(c);
c=sin(d);
}