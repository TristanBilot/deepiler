#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=(asin(b))-(exp(e));
a=pow(c,f);
e=cos(c);
b=exp(e);
d=floor(e);
e=(floor(b))+(fmin(e,f));
b=(asin(c))*(sqrt(e));
while(isgreaterequal(b,e)){
d=log10(b);
a=atan2(e,c);
f=log10(d);
b=fdim(f,f);
}
}