#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=exp(e);
d=fmin(a,b);
a=sqrt(d);
b=pow(c,e);
e=(exp(c))+(atan(d));
d=(fdim(c,c))*(fmin(f,f));
f=(asin(e))+(fmin(f,b));
a=fmax(e,a);
f=(fmin(b,a))+(sqrt(a));
c=tan(f);
c=(atan2(c,b))+(asin(f));
b=(log10(e))+(fmax(f,c));
e=log10(b);
f=pow(e,a);
}