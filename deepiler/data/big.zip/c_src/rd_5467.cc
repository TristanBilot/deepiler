#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
h=(fmax(f,g))+(floor(e));
b=log10(g);
h=(fmax(d,h))*(fmax(c,d));
if(isgreaterequal(b,h)){
g=(fmax(d,g))-(fmin(e,d));
c=fmin(e,h);
}
f=atan(e);
b=(pow(b,c))+(fmin(g,e));
f=(asin(f))/(acos(e));
c=(atan2(h,e))-(asin(e));
d=atan2(a,h);
}