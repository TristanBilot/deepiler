#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=atan2(a,e);
a=exp(f);
b=(asin(f))*(asin(b));
c=(log10(e))+(exp(e));
c=(log(e))-(tan(d));
d=log(e);
f=atan2(e,a);
e=pow(b,a);
if(islessequal(b,b)){
f=(atan(a))-(fmax(a,c));
e=sqrt(f);
a=fmax(a,a);
}
else{
d=fmax(c,a);
d=(pow(f,d))+(atan(c));
}
}