#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(cos(b))+(atan(b));
b=fdim(b,d);
if(islessequal(e,c)){
d=(atan2(e,b))/(acos(e));
d=(fmax(b,e))-(pow(e,b));
c=(fmax(e,d))/(acos(c));
c=exp(e);
}
else{
e=(sin(a))*(floor(b));
d=(tan(a))/(exp(a));
d=fmax(c,e);
c=(pow(d,c))-(atan2(a,a));
}
if(islessequal(c,e)){
d=fmax(e,a);
c=(fmin(c,b))/(pow(a,d));
b=atan2(e,d);
e=(pow(e,e))/(atan2(c,a));
a=(atan2(a,b))/(asin(a));
}
else{
b=(atan2(c,c))/(fmin(c,e));
d=fmax(c,c);
b=exp(c);
c=(ceil(a))/(acos(d));
e=pow(e,a);
}
}