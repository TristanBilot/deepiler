#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=log10(e);
b=cos(c);
b=fmax(b,d);
c=fdim(a,a);
e=sin(e);
e=(fmin(f,b))+(fmax(b,e));
f=pow(b,f);
f=asin(e);
a=(fmin(f,f))+(fmax(b,e));
if(islessequal(a,f)){
e=(floor(b))-(fmin(e,b));
e=(fmin(f,f))*(fmin(a,d));
}
else{
b=(pow(b,f))+(log10(f));
e=log10(c);
}
}