#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=(asin(b))-(floor(f));
d=(fdim(e,d))*(atan2(g,c));
a=(atan(f))*(log10(d));
if(isgreaterequal(f,d)){
b=(log(e))+(floor(a));
d=(pow(f,c))+(tan(c));
a=floor(g);
f=(atan2(c,f))*(sin(a));
}
if(islessequal(c,a)){
g=(cos(b))/(log10(a));
a=(fmax(f,g))*(log10(a));
e=(tan(f))-(pow(a,a));
g=(exp(d))*(fdim(a,e));
d=fdim(c,g);
}
else{
d=tan(f);
g=(fdim(b,e))-(fmax(b,e));
}
}