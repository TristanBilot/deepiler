#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=asin(c);
a=sin(e);
d=atan2(c,e);
while(isgreaterequal(b,e)){
d=(tan(f))*(tan(b));
a=fmin(a,f);
c=(fmax(a,f))+(atan2(b,e));
}
while(islessequal(b,e)){
d=pow(a,c);
e=(floor(d))/(log(a));
}
}