#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=(floor(a))*(atan2(f,d));
d=atan(c);
e=fmin(d,e);
d=(pow(b,a))/(sin(a));
a=(atan(d))/(floor(c));
b=fmax(b,a);
d=(atan2(e,b))+(floor(f));
d=(exp(d))*(fmax(b,d));
if(isless(a,e)){
c=fmin(a,d);
f=(asin(a))-(atan2(e,f));
e=fmin(d,b);
}
}