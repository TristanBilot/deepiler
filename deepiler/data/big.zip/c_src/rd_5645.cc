#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(pow(b,b))-(sqrt(b));
a=fmin(a,c);
while(isless(a,e)){
c=cos(b);
d=(fmin(c,b))+(log10(e));
c=fdim(e,e);
c=(atan(c))-(tan(d));
}
b=atan2(e,d);
d=log10(e);
e=fmin(d,e);
}