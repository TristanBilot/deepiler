#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=pow(d,g);
g=fdim(f,h);
d=(pow(h,h))/(log(c));
b=(fdim(a,b))*(sin(c));
g=(exp(f))/(fdim(e,e));
while(islessgreater(g,a)){
h=(cos(f))/(floor(e));
g=(fmin(c,a))+(sqrt(b));
}
g=fdim(e,g);
a=sin(a);
e=(log10(a))/(atan2(d,e));
}