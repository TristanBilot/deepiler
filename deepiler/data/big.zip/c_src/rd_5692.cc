#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
a=(asin(e))*(atan(d));
g=(sqrt(b))-(exp(f));
b=exp(a);
h=(exp(g))*(floor(g));
b=fmin(d,a);
b=asin(a);
f=(fdim(d,g))/(exp(d));
c=(fdim(e,c))+(fmin(f,b));
c=(pow(e,f))*(log10(a));
h=(fdim(e,f))+(log(c));
if(islessequal(e,a)){
c=(atan(e))/(fdim(a,e));
c=exp(e);
}
else{
e=(acos(a))-(fdim(d,d));
b=exp(f);
e=(acos(b))/(log10(b));
b=(fmax(b,c))/(fmax(e,g));
}
}