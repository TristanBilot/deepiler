#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
e=floor(f);
g=(fmax(g,c))*(pow(e,a));
if(isgreaterequal(g,b)){
g=fdim(d,c);
c=fdim(b,d);
d=atan2(g,g);
f=(pow(d,b))+(fmin(a,g));
}
if(islessequal(c,c)){
f=acos(b);
f=(log10(c))/(cos(b));
}
else{
d=(atan2(g,g))-(pow(f,b));
g=exp(g);
a=(pow(d,d))/(fmax(b,d));
}
}