#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=floor(e);
f=tan(a);
a=(log10(d))*(atan(f));
d=cos(b);
b=(fdim(c,c))/(fdim(a,a));
c=(exp(c))/(tan(b));
a=fmin(a,c);
while(islessgreater(e,d)){
b=exp(c);
f=fdim(d,b);
}
}