#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(exp(c))/(asin(e));
e=atan2(b,d);
a=acos(d);
c=atan2(a,b);
a=(pow(c,e))/(asin(d));
a=(ceil(c))*(atan2(d,c));
e=(sin(d))-(fdim(c,b));
d=acos(b);
b=(floor(a))+(log10(b));
}