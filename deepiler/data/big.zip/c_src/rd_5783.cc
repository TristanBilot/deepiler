#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=(fdim(c,f))-(pow(d,a));
f=(atan(b))+(atan2(h,d));
while(isgreaterequal(b,f)){
d=(fmax(c,c))-(pow(c,e));
b=(fmax(g,e))+(atan2(b,c));
g=(pow(g,e))/(fmax(e,h));
a=pow(e,f);
}
while(isgreaterequal(f,d)){
f=cos(b);
h=(atan(d))*(pow(d,a));
d=exp(a);
f=pow(f,g);
}
}