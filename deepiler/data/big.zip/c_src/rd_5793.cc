#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
e=(fdim(c,a))-(log10(f));
g=pow(d,f);
f=log10(b);
f=floor(a);
b=(pow(g,a))+(atan2(d,f));
b=(floor(c))+(floor(c));
b=(floor(a))*(fdim(a,f));
f=pow(c,b);
g=asin(c);
f=(sin(c))+(ceil(a));
b=(fmin(f,e))/(pow(c,a));
f=(ceil(g))+(fmin(b,e));
}