#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=tan(g);
a=(fdim(d,g))*(atan2(b,c));
c=(exp(d))-(fdim(b,h));
b=(fmin(h,e))+(fmin(g,e));
a=(fmax(h,f))-(ceil(f));
c=atan2(e,d);
b=atan2(g,d);
h=atan(h);
b=(fmin(g,h))+(log10(c));
d=(fdim(b,a))+(pow(a,c));
d=atan(d);
}