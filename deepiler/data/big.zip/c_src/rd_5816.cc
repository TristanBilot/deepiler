#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=(pow(e,e))-(exp(d));
d=fmax(c,e);
b=(fmin(b,a))*(exp(b));
e=atan2(b,e);
b=ceil(a);
b=(exp(b))-(exp(c));
e=(log10(b))/(asin(c));
b=fmin(c,c);
b=(asin(a))/(atan(c));
c=(fmin(a,c))+(asin(a));
d=(fmin(c,c))-(sin(a));
a=fdim(e,e);
}