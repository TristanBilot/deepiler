#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=atan2(e,e);
c=tan(f);
e=log(b);
h=(pow(h,g))+(pow(e,g));
while(isgreaterequal(b,h)){
d=atan(e);
d=atan2(a,e);
f=(fmax(d,h))-(fmax(d,g));
d=(fmin(c,d))-(acos(a));
}
if(islessgreater(d,a)){
a=log(b);
b=(sqrt(a))+(fmin(h,h));
a=pow(d,b);
h=(pow(e,a))/(fdim(f,b));
d=(fmin(d,g))/(floor(g));
}
else{
g=ceil(g);
b=(fdim(b,d))/(log(h));
e=(cos(c))/(cos(e));
g=(atan2(f,e))*(atan(d));
b=pow(e,h);
}
}