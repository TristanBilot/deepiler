#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=(pow(c,a))+(fdim(c,c));
c=(fmin(e,e))-(floor(f));
a=(exp(b))+(log10(d));
e=fmax(d,c);
d=(fdim(f,c))-(atan2(a,a));
d=sqrt(a);
a=(fdim(f,e))*(asin(b));
a=(fdim(e,c))*(fmax(d,e));
c=(fdim(c,c))+(fmax(b,a));
if(islessequal(d,a)){
b=(atan2(d,a))-(log(d));
f=(pow(b,d))/(atan2(b,b));
e=asin(e);
e=atan(d);
}
}