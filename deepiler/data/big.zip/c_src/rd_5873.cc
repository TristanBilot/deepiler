#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(fmin(d,b))+(fmin(a,a));
e=cos(c);
while(islessgreater(b,d)){
a=(fmin(e,b))/(pow(b,c));
e=(ceil(b))*(fmin(d,e));
}
c=(asin(a))-(log10(e));
c=fmax(a,a);
a=(fmin(c,a))*(sqrt(c));
b=floor(a);
}