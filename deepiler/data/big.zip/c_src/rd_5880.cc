#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
e=floor(c);
g=fdim(e,g);
a=(exp(g))*(atan2(g,g));
g=log(g);
b=atan2(f,c);
if(islessequal(g,a)){
g=log(f);
c=(tan(e))*(asin(e));
}
else{
f=atan2(g,e);
f=pow(f,d);
e=(sin(b))+(fmax(e,e));
d=(fmax(g,f))-(sqrt(e));
c=atan2(d,d);
}
while(islessequal(b,d)){
a=(pow(d,a))*(tan(b));
a=fmax(b,e);
c=fmax(c,d);
e=pow(a,d);
b=(ceil(e))-(pow(f,e));
}
}