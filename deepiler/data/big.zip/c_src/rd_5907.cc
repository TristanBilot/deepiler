#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(cos(e))+(pow(b,a));
e=(atan2(d,a))*(atan2(b,a));
while(islessequal(b,c)){
b=sin(a);
b=log(f);
c=atan2(a,a);
c=atan(d);
d=(exp(f))+(exp(d));
}
if(isless(e,f)){
a=(log10(d))-(log10(a));
f=(log10(d))-(atan(a));
}
else{
b=fmin(b,e);
a=(cos(b))+(fdim(d,c));
f=fdim(b,f);
c=fmax(b,e);
}
}