#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
h=(fdim(h,b))/(fdim(g,d));
c=tan(c);
h=exp(f);
b=(tan(b))-(fdim(h,a));
e=(fdim(c,b))-(sqrt(a));
e=(floor(f))+(fmin(f,a));
h=(fdim(a,g))-(floor(e));
a=fmin(c,e);
a=(fmax(d,f))-(pow(a,c));
h=exp(b);
}