#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=exp(b);
d=(atan2(e,b))/(fmin(c,d));
e=log(d);
c=fmin(b,d);
if(islessgreater(c,e)){
e=atan2(a,c);
b=sin(a);
c=fdim(c,d);
e=fmin(c,e);
}
else{
a=log10(b);
a=atan2(a,c);
d=(acos(a))/(pow(e,a));
}
}