#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=(fdim(g,c))+(fmax(e,b));
a=(tan(a))*(sqrt(g));
d=log(b);
e=(fdim(a,f))+(fmin(g,b));
f=(asin(a))-(asin(f));
e=fdim(c,a);
f=(pow(e,g))/(fmax(c,e));
f=(log(d))+(atan(c));
c=pow(b,e);
g=sin(a);
f=(pow(d,a))/(fmax(b,a));
e=(fmax(f,f))+(fdim(b,e));
}