#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=(sin(b))/(fmin(a,c));
e=fmax(a,d);
d=(sin(e))-(fmin(b,c));
a=(asin(a))*(asin(b));
b=floor(c);
if(isless(e,b)){
e=acos(f);
b=(sin(d))+(sqrt(b));
f=fdim(d,a);
f=(atan2(e,f))/(asin(d));
f=(sin(c))*(log10(b));
}
else{
b=ceil(a);
d=log10(d);
}
if(islessequal(b,a)){
b=(atan2(d,c))+(sin(a));
a=(tan(f))*(pow(a,e));
}
else{
f=(fmin(a,a))*(fmin(c,b));
e=cos(c);
c=fdim(e,d);
}
}