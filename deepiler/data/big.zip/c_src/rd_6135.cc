#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=(pow(e,h))+(asin(b));
f=(tan(f))+(atan(b));
b=(atan2(g,h))*(sqrt(a));
a=(pow(c,d))/(exp(b));
h=atan(d);
while(isless(h,h)){
a=(fmax(c,b))-(acos(c));
d=(floor(d))/(log10(f));
}
g=(fdim(d,h))*(atan2(b,a));
h=fmax(g,f);
h=fmax(g,h);
f=log10(h);
h=(pow(h,a))*(fdim(b,g));
}