#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=log(b);
c=(fmax(a,e))-(asin(d));
d=(atan2(c,b))/(tan(b));
b=fdim(e,c);
e=(sqrt(d))/(cos(b));
c=floor(c);
e=(fmax(b,a))+(fmax(c,b));
a=(acos(b))*(asin(d));
d=ceil(a);
if(islessgreater(b,e)){
d=(sqrt(b))+(atan2(d,b));
c=pow(e,b);
b=(fdim(c,d))/(cos(c));
b=pow(e,a);
}
else{
a=(asin(b))/(exp(d));
e=pow(a,e);
}
}