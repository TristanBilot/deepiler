#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=cos(c);
a=(atan2(e,g))/(fmin(g,e));
c=(fmax(c,g))*(fmax(g,f));
d=pow(b,c);
a=(fdim(b,e))-(fmax(f,f));
a=pow(f,a);
a=(asin(c))/(fmax(d,d));
a=(atan(f))*(tan(g));
c=(sqrt(a))/(fmax(g,b));
g=(fdim(a,g))*(ceil(f));
f=(fmin(d,e))+(fdim(b,b));
g=(exp(a))+(floor(g));
}