#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=acos(a);
c=floor(b);
d=(fmin(a,c))/(sin(c));
d=(log10(d))/(cos(b));
a=floor(b);
b=atan2(c,c);
c=(fmin(c,e))-(log10(c));
b=sqrt(b);
c=exp(c);
c=(sqrt(c))+(atan2(e,c));
c=(asin(a))/(fmax(b,b));
b=(cos(a))-(pow(e,c));
}