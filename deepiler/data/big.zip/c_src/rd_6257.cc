#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=log(a);
c=fmin(g,a);
h=pow(f,d);
d=log(e);
if(islessequal(h,g)){
f=(atan2(c,f))*(exp(c));
g=ceil(a);
a=(fmax(c,b))*(atan(g));
}
else{
a=(sqrt(c))+(fmax(c,c));
c=tan(f);
h=acos(b);
}
if(isgreaterequal(a,e)){
f=fmax(c,g);
a=(fdim(c,d))*(asin(f));
}
}