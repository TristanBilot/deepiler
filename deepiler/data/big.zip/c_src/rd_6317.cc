#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=fmax(a,f);
a=(fdim(a,a))/(fmax(d,f));
e=fmax(a,d);
b=ceil(d);
f=fdim(a,d);
c=(pow(e,a))+(sqrt(b));
c=(atan2(f,c))/(asin(c));
f=sqrt(f);
d=pow(f,d);
}