#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=(ceil(e))*(tan(d));
f=(atan(b))/(fmax(e,a));
c=atan(a);
a=(atan(d))+(pow(a,e));
f=(log(c))-(fmax(g,d));
a=(exp(e))/(cos(c));
a=(exp(c))+(fdim(c,g));
d=(fmin(f,e))-(fmax(b,d));
if(isgreaterequal(e,d)){
c=fmin(f,a);
c=(fdim(b,a))*(floor(b));
g=(asin(g))/(log10(d));
c=cos(c);
a=(atan2(g,c))*(cos(g));
}
else{
e=atan2(a,f);
a=(log(a))/(tan(f));
e=atan(e);
a=fdim(b,g);
b=fmin(a,b);
}
}