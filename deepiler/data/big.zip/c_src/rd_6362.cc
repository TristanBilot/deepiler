#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=tan(e);
g=cos(e);
d=fmax(d,g);
a=(asin(g))-(sqrt(d));
if(islessequal(a,g)){
e=(acos(d))*(fdim(c,b));
g=tan(b);
}
if(isgreaterequal(g,b)){
a=(log10(e))/(ceil(a));
g=ceil(b);
d=fmin(d,e);
}
}