#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=fmin(f,f);
a=log10(f);
if(islessgreater(e,b)){
d=(fdim(b,e))*(fmin(d,e));
g=(fdim(a,e))/(pow(a,e));
d=(cos(e))*(fmax(f,a));
}
else{
b=fmin(g,c);
b=fmax(c,g);
g=(log(a))*(fmax(d,g));
a=log(c);
b=sin(g);
}
b=(exp(d))*(pow(c,d));
b=(pow(g,a))+(fdim(b,g));
}