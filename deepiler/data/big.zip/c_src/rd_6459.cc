#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(acos(a))*(fmax(e,a));
d=atan2(e,e);
a=pow(c,a);
d=cos(d);
if(isless(b,d)){
b=log(d);
b=(pow(d,c))-(fmin(c,e));
c=(fmin(e,d))/(log10(e));
e=(log(c))+(fdim(d,e));
}
if(islessgreater(d,d)){
e=(acos(d))*(sqrt(e));
d=(fdim(c,e))*(log10(e));
e=fmax(d,d);
d=pow(b,d);
}
}