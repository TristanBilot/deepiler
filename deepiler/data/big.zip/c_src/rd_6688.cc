#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=(ceil(a))/(fmax(c,a));
c=fdim(f,b);
a=(atan2(f,e))/(sin(f));
while(isless(f,e)){
b=(cos(d))+(pow(b,c));
d=(tan(b))/(fdim(e,a));
c=(fdim(c,f))/(exp(e));
c=(pow(c,d))-(cos(e));
e=(pow(c,d))*(log10(b));
}
e=fmax(e,f);
f=fdim(b,d);
b=(atan2(a,c))/(fmax(d,e));
f=fmax(c,a);
}