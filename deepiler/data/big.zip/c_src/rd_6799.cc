#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=(fmin(f,e))/(fdim(a,f));
e=(ceil(c))-(fdim(d,f));
e=(fmax(d,a))/(atan2(d,c));
a=fdim(c,b);
b=(pow(a,e))+(fmax(e,b));
c=(atan2(b,d))*(fmax(d,b));
b=exp(b);
if(islessgreater(f,c)){
e=fdim(b,e);
d=fmin(a,c);
e=(atan2(d,b))+(atan(e));
c=fdim(e,e);
}
}