#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=(floor(a))/(fmin(c,a));
h=(fdim(b,a))/(fmin(c,f));
b=(exp(b))+(fdim(d,d));
g=(fdim(b,a))-(sqrt(h));
h=(sqrt(c))*(atan2(d,d));
while(isgreaterequal(e,g)){
h=(atan2(h,f))+(fmax(h,c));
d=(pow(e,c))+(tan(d));
g=fdim(h,f);
a=exp(g);
h=fmin(d,h);
}
}