#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=(atan(b))*(fdim(b,e));
e=cos(b);
a=pow(d,a);
while(islessequal(c,e)){
c=(fmax(b,b))*(pow(c,c));
d=ceil(c);
d=(cos(d))+(fmin(c,c));
d=(atan2(a,d))+(atan2(c,a));
c=(fdim(a,e))+(acos(b));
}
while(islessequal(c,e)){
c=(sin(a))/(cos(a));
e=pow(a,c);
e=log10(e);
c=sin(c);
}
}