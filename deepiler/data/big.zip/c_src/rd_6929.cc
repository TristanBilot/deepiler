#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(fmin(d,e))+(fmax(c,d));
c=atan2(d,d);
if(isless(c,d)){
c=(atan2(b,b))/(sqrt(b));
e=fmin(e,a);
b=(fmax(b,c))/(fmax(c,d));
d=(atan2(b,c))*(sqrt(d));
}
c=fmin(d,a);
a=(tan(d))+(atan2(e,a));
d=acos(c);
d=fmin(e,c);
d=log10(b);
}