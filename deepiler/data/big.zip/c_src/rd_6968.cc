#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=fdim(a,c);
c=pow(e,a);
d=(pow(a,e))/(log10(d));
while(isless(a,e)){
a=log(e);
a=(floor(e))+(log(b));
c=fdim(c,e);
}
e=(atan2(d,a))*(log(d));
a=(pow(d,c))+(atan2(d,a));
d=(fmax(a,e))-(fmax(e,a));
e=(atan2(b,e))/(log10(d));
}