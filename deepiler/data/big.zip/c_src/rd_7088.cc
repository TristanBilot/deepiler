#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=(fmax(e,c))+(pow(b,e));
c=(fmin(e,f))+(sin(e));
a=fmin(h,g);
f=(ceil(f))*(fdim(b,d));
h=atan2(a,h);
c=fmax(e,d);
d=log10(f);
e=(atan(h))-(fmin(f,a));
b=fmax(e,a);
if(islessequal(g,d)){
a=sin(b);
e=(pow(f,h))-(floor(g));
g=(log10(a))+(atan(b));
}
else{
g=asin(g);
a=(fmax(c,f))/(fmax(a,f));
c=(fmin(h,b))*(log(c));
f=(asin(f))+(atan2(c,g));
}
}