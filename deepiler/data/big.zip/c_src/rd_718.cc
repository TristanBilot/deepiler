#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=tan(c);
c=atan2(e,f);
d=(fmax(a,f))+(exp(d));
b=(floor(a))*(atan2(d,f));
if(isless(c,e)){
a=(atan2(c,d))+(fmin(b,d));
a=(fmax(b,d))/(atan(f));
}
while(isgreaterequal(e,a)){
a=(tan(e))/(fmin(d,b));
f=asin(d);
d=(fmax(a,a))-(floor(c));
}
}