#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=acos(a);
e=tan(d);
while(isgreaterequal(a,c)){
c=pow(e,b);
c=pow(f,d);
}
while(isgreaterequal(d,d)){
b=atan(c);
c=(pow(c,b))+(asin(g));
b=(fmin(b,a))*(cos(f));
a=fmin(b,b);
f=(fmax(d,c))*(fmax(c,b));
}
}