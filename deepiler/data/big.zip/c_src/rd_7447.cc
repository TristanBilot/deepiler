#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(pow(c,e))/(tan(a));
b=(atan2(a,b))/(fdim(e,a));
a=(fmax(c,b))+(fdim(d,b));
b=(tan(b))*(sin(c));
c=tan(d);
if(islessequal(a,a)){
a=(atan(e))*(atan2(e,e));
d=(fmax(d,e))+(exp(b));
a=pow(d,d);
}
else{
e=pow(d,d);
d=fmax(a,d);
e=(sqrt(d))+(fdim(c,e));
b=(log(e))+(log(d));
e=log(e);
}
if(islessgreater(e,c)){
c=(sin(b))+(pow(c,a));
d=fdim(a,e);
c=(ceil(a))-(log10(e));
}
else{
c=(acos(e))-(atan2(d,a));
c=(asin(a))/(sin(c));
}
}