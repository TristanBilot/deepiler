#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
h=fmax(c,g);
d=(sqrt(f))-(log(a));
h=tan(b);
a=(fmax(b,f))*(fdim(h,f));
while(islessequal(f,d)){
h=fmin(e,h);
b=(asin(f))+(pow(b,e));
a=(fdim(f,c))/(fmin(c,c));
d=(cos(g))*(exp(c));
}
if(islessgreater(a,e)){
a=(log(d))+(fmax(c,g));
d=(sin(f))+(sqrt(g));
}
else{
e=fdim(f,h);
c=atan(a);
d=(fmax(a,d))/(log10(c));
}
}