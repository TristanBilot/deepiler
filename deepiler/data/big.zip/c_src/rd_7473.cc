#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=(floor(b))+(atan(e));
e=(fdim(f,a))-(cos(d));
f=atan2(d,f);
d=log10(b);
if(islessequal(e,e)){
e=ceil(b);
e=acos(f);
}
while(islessgreater(f,b)){
c=(fmin(c,f))/(acos(b));
e=pow(b,b);
d=(pow(a,b))/(acos(c));
}
}