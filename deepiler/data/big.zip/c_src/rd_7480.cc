#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=fmax(a,a);
e=exp(b);
e=ceil(g);
g=fmax(f,g);
c=(atan2(e,d))*(atan2(c,b));
c=sqrt(c);
while(islessequal(c,c)){
f=(pow(a,c))-(log(c));
d=log10(d);
b=fdim(f,b);
}
}