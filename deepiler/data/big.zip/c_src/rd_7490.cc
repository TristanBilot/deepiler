#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=(pow(e,a))+(log10(d));
a=atan2(e,a);
e=(pow(b,f))/(tan(b));
f=(fdim(b,e))+(cos(a));
b=(fdim(d,e))+(asin(b));
e=(atan2(d,e))/(pow(e,e));
a=log10(d);
a=(fmin(d,d))+(sin(d));
f=(pow(a,a))/(asin(b));
c=(atan2(a,b))+(fdim(e,c));
if(islessequal(e,b)){
e=atan2(e,a);
e=atan2(f,f);
e=fmin(a,f);
f=(asin(e))-(tan(f));
b=(cos(e))*(fdim(e,f));
}
else{
d=(sin(f))-(atan2(d,d));
d=log10(f);
d=fmax(c,a);
}
}