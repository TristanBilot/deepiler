#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=(acos(c))+(atan2(c,d));
b=ceil(e);
e=atan2(b,a);
d=pow(c,a);
f=cos(f);
c=(pow(f,c))*(exp(d));
a=(pow(d,f))+(tan(e));
b=(cos(f))-(fmax(e,b));
a=pow(e,d);
d=(acos(a))-(ceil(e));
d=(fdim(b,d))*(log(a));
a=tan(b);
b=(log10(f))+(fmin(e,b));
}