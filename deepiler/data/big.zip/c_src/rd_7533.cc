#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=log10(b);
e=(acos(a))+(fmax(a,e));
e=fdim(c,e);
while(isless(b,c)){
e=fmin(e,c);
d=(fmax(e,e))+(log(e));
e=(exp(c))-(pow(b,b));
b=cos(a);
}
while(isless(e,e)){
d=cos(c);
a=(sqrt(d))-(fmax(c,d));
e=log10(e);
e=(fmin(d,e))/(cos(b));
}
}