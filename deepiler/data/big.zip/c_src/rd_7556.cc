#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=log(c);
b=(fmax(d,e))+(fdim(c,c));
c=(log(c))-(tan(c));
e=(ceil(d))*(atan2(b,e));
a=(sqrt(b))-(atan2(a,c));
a=(atan2(d,a))*(floor(d));
f=fmin(b,f);
if(islessequal(b,a)){
c=fdim(a,f);
e=pow(d,f);
f=pow(e,c);
}
else{
a=(cos(f))/(atan2(e,b));
a=(pow(e,f))/(cos(a));
}
}