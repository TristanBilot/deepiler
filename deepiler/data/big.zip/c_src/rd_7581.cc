#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=(atan2(a,c))*(pow(g,f));
b=atan2(g,d);
a=sqrt(e);
g=sin(d);
e=fdim(b,c);
a=(atan2(b,f))+(exp(a));
c=asin(f);
g=fmin(d,b);
if(isgreaterequal(a,a)){
c=fmin(g,f);
e=sqrt(b);
e=acos(d);
d=fmin(a,c);
}
else{
c=(acos(e))/(cos(g));
b=sin(c);
e=cos(f);
}
}