#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=atan(e);
c=(cos(a))*(sin(e));
b=(fmax(d,e))*(fmin(b,a));
b=atan2(b,f);
if(isgreaterequal(b,c)){
a=(fmax(b,d))/(atan2(f,e));
c=(pow(f,c))/(fmin(a,f));
c=log(a);
f=(fdim(c,d))/(pow(e,c));
}
else{
d=fdim(a,d);
a=fdim(a,d);
f=pow(b,a);
f=(fmax(d,f))*(tan(b));
}
a=atan2(d,e);
d=(log(d))*(fmax(d,f));
c=(atan(c))+(fmax(a,f));
b=pow(f,f);
a=(pow(b,a))-(sin(b));
}