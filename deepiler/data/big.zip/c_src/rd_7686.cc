#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(atan(b))/(sin(d));
c=fmin(c,e);
e=(fdim(d,a))/(fdim(a,e));
c=(atan2(e,b))-(fmin(b,a));
a=cos(c);
while(isgreaterequal(a,e)){
e=fdim(c,a);
d=atan(b);
d=atan(a);
}
}