#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=(fdim(a,e))/(atan2(d,d));
d=floor(b);
a=(cos(e))/(sin(d));
b=(cos(d))*(atan(e));
while(isgreaterequal(a,e)){
a=(fmax(e,c))-(sqrt(d));
e=atan2(a,c);
}
e=fmax(a,e);
a=(fdim(c,c))/(pow(b,d));
d=fmin(e,e);
}