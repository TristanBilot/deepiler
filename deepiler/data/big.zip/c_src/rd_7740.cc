#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(fmax(b,a))-(atan(a));
b=(ceil(e))*(fmax(c,a));
e=(floor(c))*(sin(e));
c=(atan2(b,d))-(sqrt(a));
if(isless(c,d)){
e=(pow(d,e))-(exp(a));
e=(fmax(a,a))-(pow(c,a));
c=(asin(b))/(atan2(a,e));
a=(pow(e,a))-(fdim(d,b));
}
else{
a=floor(b);
b=(atan2(a,d))/(tan(c));
d=(exp(d))+(fmax(c,e));
}
c=(sqrt(a))*(log(d));
d=pow(b,a);
b=tan(b);
a=(sqrt(e))/(pow(c,c));
}