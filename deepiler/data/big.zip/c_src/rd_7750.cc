#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=sin(a);
b=(pow(d,d))+(log(d));
f=sqrt(f);
e=fdim(b,e);
a=fdim(f,a);
d=sin(d);
f=asin(d);
}