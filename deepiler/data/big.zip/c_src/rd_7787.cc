#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=log10(a);
a=(floor(e))*(log10(c));
b=(atan2(c,d))*(acos(b));
e=log10(c);
d=pow(c,a);
b=(log10(c))*(pow(e,e));
c=fmin(c,a);
d=pow(c,e);
d=(fmax(d,b))+(log(b));
d=(log10(c))/(acos(b));
c=pow(c,c);
d=(acos(c))+(tan(c));
c=fdim(d,c);
c=(acos(d))*(atan2(a,e));
}