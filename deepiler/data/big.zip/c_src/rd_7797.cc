#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(pow(c,e))*(acos(e));
a=(sin(c))*(fmax(d,e));
if(islessequal(b,e)){
c=(ceil(a))*(atan2(e,a));
e=asin(a);
c=(acos(b))*(fdim(e,d));
d=(log10(b))+(acos(b));
e=(atan2(a,e))*(fmax(a,b));
}
else{
c=pow(c,c);
c=(sqrt(e))/(fmax(b,a));
}
if(isless(e,c)){
a=(fmax(e,b))*(pow(b,b));
d=(atan2(d,d))*(fmax(e,e));
c=fmax(a,c);
c=(sqrt(a))-(fdim(b,a));
}
else{
a=(atan2(b,d))-(exp(e));
d=atan(d);
}
}