#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
a=atan2(d,b);
a=atan2(g,a);
d=fmin(g,e);
b=(fmin(a,a))-(ceil(d));
while(islessequal(g,b)){
g=asin(c);
b=(fmin(b,f))+(fmax(e,e));
f=(sin(a))-(acos(f));
}
if(isgreaterequal(a,d)){
b=ceil(c);
f=exp(f);
e=fmax(g,b);
a=asin(a);
c=fmax(e,a);
}
else{
c=(pow(c,h))*(fmin(f,h));
b=(fmin(a,b))/(sqrt(f));
}
}