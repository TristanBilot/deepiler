#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=pow(a,c);
e=(log(d))+(atan2(a,c));
d=(atan2(f,b))/(fmax(d,b));
a=fdim(e,b);
d=cos(b);
b=(log10(f))+(fmin(f,e));
b=log(a);
a=tan(c);
a=(fmax(d,b))/(atan(f));
b=(pow(e,b))-(exp(a));
if(islessequal(e,d)){
e=fmin(c,c);
f=(pow(a,e))+(fdim(b,d));
a=atan2(e,d);
a=exp(b);
a=atan2(f,a);
}
else{
a=fmax(d,f);
e=(sin(b))/(fdim(a,f));
}
}