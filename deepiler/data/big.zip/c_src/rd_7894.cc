#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=log10(b);
a=sqrt(e);
b=(fmax(c,a))/(atan2(e,e));
if(islessgreater(b,d)){
e=(sin(e))/(fmax(a,e));
d=fmin(b,b);
d=(fmin(e,e))-(fdim(c,c));
d=(atan2(e,e))*(fdim(b,e));
}
if(islessgreater(d,b)){
c=fmin(e,b);
e=(sin(b))/(fdim(a,a));
}
else{
c=atan2(a,a);
d=acos(a);
c=pow(a,c);
}
}