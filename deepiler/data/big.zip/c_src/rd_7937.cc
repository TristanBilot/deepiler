#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=fmax(b,b);
b=atan(b);
e=asin(b);
c=(exp(a))*(floor(e));
e=sqrt(e);
a=fdim(a,c);
d=(ceil(a))/(atan2(a,e));
a=fdim(c,a);
c=cos(a);
while(islessequal(d,e)){
b=sqrt(d);
e=(fmax(a,d))/(sqrt(a));
}
}