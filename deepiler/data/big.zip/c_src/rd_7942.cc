#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
b=pow(c,f);
f=log(a);
h=pow(h,e);
d=log10(a);
if(isgreaterequal(d,f)){
e=(fdim(d,e))/(cos(f));
a=(fmax(h,g))-(fdim(d,h));
d=fmax(c,e);
}
else{
b=(fmin(f,d))*(sqrt(g));
f=(floor(d))+(fdim(g,g));
f=floor(f);
}
b=log10(e);
f=floor(a);
}