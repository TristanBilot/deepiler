#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=(pow(b,c))*(exp(h));
g=(fdim(f,g))+(atan2(d,e));
f=(atan2(f,h))+(fmin(g,h));
g=fmin(e,f);
h=fdim(f,h);
if(islessequal(h,c)){
g=(fdim(a,a))+(atan2(h,b));
f=tan(f);
a=(sin(c))+(fmin(e,e));
b=log(a);
}
c=(fmax(d,h))+(pow(g,h));
f=log(e);
a=pow(g,h);
a=exp(f);
}