#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=fmax(g,e);
c=(atan2(f,d))/(fdim(d,f));
f=(sin(a))/(log(a));
e=(fmin(c,f))+(asin(b));
d=(ceil(f))*(atan2(g,b));
while(isgreaterequal(d,f)){
a=(sqrt(g))*(log(d));
d=tan(c);
g=atan2(g,d);
d=sqrt(d);
}
while(isless(b,e)){
e=(fmax(a,c))+(fdim(e,c));
a=(ceil(d))*(log10(g));
g=sqrt(g);
b=(pow(a,f))-(pow(d,a));
g=(asin(a))-(sqrt(g));
}
}