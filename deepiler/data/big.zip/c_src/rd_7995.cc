#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=tan(e);
d=(fdim(d,b))+(floor(b));
b=(tan(a))-(fmin(a,c));
c=atan2(f,c);
f=fdim(e,e);
f=fmin(a,b);
e=fmax(e,b);
d=(fmax(e,c))+(fdim(a,d));
while(isgreaterequal(d,f)){
b=(exp(e))/(fmin(f,c));
b=(atan2(b,c))-(atan2(f,a));
c=fmax(c,f);
}
}