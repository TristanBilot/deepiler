#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=fmax(e,e);
a=(atan(h))+(pow(e,b));
f=(atan2(h,h))+(atan(d));
e=pow(c,e);
g=atan2(e,h);
if(islessgreater(e,e)){
e=(log10(f))-(pow(d,e));
h=fmin(f,c);
g=log(e);
g=acos(e);
}
else{
h=(fdim(h,d))/(fmax(d,d));
c=(acos(g))+(pow(e,h));
c=(pow(e,e))/(cos(d));
d=(exp(b))/(sin(g));
b=fdim(g,b);
}
}