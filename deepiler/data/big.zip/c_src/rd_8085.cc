#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=asin(a);
b=(fmin(e,a))+(fmax(c,c));
e=(fmax(f,b))-(fdim(b,d));
d=pow(e,e);
e=sqrt(d);
a=sqrt(b);
f=(ceil(f))+(pow(f,f));
a=acos(d);
f=(floor(c))+(log10(c));
b=fmax(f,a);
d=exp(d);
}