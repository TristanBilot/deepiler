#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
c=(fmin(e,b))+(floor(b));
f=(asin(c))/(atan2(e,f));
g=acos(b);
c=(log10(f))+(fmin(d,f));
h=fmin(a,d);
f=(log10(c))*(cos(f));
a=(fmax(a,e))+(cos(b));
e=log(c);
e=fdim(b,c);
d=(fmin(b,c))-(log10(e));
a=cos(a);
d=pow(c,h);
}