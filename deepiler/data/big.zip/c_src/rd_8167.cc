#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
a=fmax(f,e);
c=(fdim(b,f))+(pow(g,e));
e=ceil(h);
b=floor(e);
if(islessequal(h,b)){
a=(fmin(e,c))+(pow(e,a));
h=ceil(e);
h=fmin(d,a);
}
else{
a=ceil(d);
b=pow(h,e);
d=(floor(d))-(atan2(g,f));
f=(pow(h,f))/(tan(h));
}
if(islessequal(e,g)){
h=fmax(b,h);
h=pow(e,g);
a=(atan2(e,c))/(fmax(c,b));
}
else{
f=(sqrt(b))*(fmin(h,d));
a=fmin(f,g);
a=(tan(g))*(atan2(d,a));
d=floor(b);
h=cos(e);
}
}