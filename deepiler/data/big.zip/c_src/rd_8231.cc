#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=acos(b);
a=sqrt(a);
e=acos(b);
b=tan(d);
while(isless(d,c)){
e=(sqrt(d))+(log(a));
a=asin(b);
d=fdim(e,d);
}
while(islessequal(b,c)){
d=(fdim(c,e))+(fmin(a,a));
b=(tan(a))/(fmin(a,e));
b=tan(c);
}
}