#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=(cos(g))/(fdim(g,d));
b=(atan2(b,d))+(floor(a));
b=atan2(b,d);
f=fmin(b,d);
c=fdim(f,g);
if(islessequal(d,f)){
a=(fdim(g,e))+(sqrt(g));
f=fmax(b,c);
g=floor(e);
c=pow(f,c);
f=(fmax(f,a))+(fmax(c,b));
}
else{
d=(acos(d))/(fmax(g,b));
e=(sqrt(d))-(sqrt(f));
a=fmax(f,d);
}
c=log(c);
e=atan2(b,d);
f=(asin(e))+(atan(a));
g=(fmin(g,c))-(tan(f));
b=(acos(b))/(fdim(e,c));
}