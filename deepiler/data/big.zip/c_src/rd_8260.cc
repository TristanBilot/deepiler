#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=(fmin(d,b))-(fmin(b,c));
h=cos(b);
b=(pow(h,a))-(cos(h));
c=sin(f);
while(islessgreater(h,a)){
a=(fmax(g,c))-(fmax(f,g));
f=fmax(e,c);
d=fmin(c,c);
d=(tan(g))-(tan(f));
}
if(islessgreater(d,a)){
a=fmin(a,a);
f=(exp(h))+(asin(b));
}
}