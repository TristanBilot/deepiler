#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(fdim(d,a))*(pow(c,c));
e=sin(d);
if(islessgreater(e,a)){
e=log10(e);
e=atan2(d,c);
c=(fdim(a,a))*(atan2(d,c));
}
while(islessequal(b,c)){
d=fmax(a,e);
b=(atan2(e,d))-(fdim(b,d));
b=(fdim(c,b))-(fdim(d,e));
}
}