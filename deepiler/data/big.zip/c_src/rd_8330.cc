#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=fdim(e,g);
h=(floor(h))+(fmin(g,g));
g=(pow(g,b))+(tan(a));
h=log(f);
d=fmin(b,b);
while(isgreaterequal(c,c)){
e=acos(h);
d=(fmax(e,a))*(tan(h));
f=fdim(g,f);
h=(fmax(a,e))/(fmax(a,f));
f=log(g);
}
if(isgreaterequal(d,d)){
b=(fmin(f,f))-(pow(g,f));
c=fmin(h,e);
f=acos(a);
}
}