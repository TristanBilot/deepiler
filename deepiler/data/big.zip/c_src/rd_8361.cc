#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=(fmin(a,c))-(pow(g,e));
a=fmax(e,d);
d=floor(g);
f=(atan(c))-(cos(b));
a=(asin(e))+(sqrt(e));
b=(sin(c))*(fdim(b,b));
b=(fdim(f,d))*(fmax(e,f));
if(isgreaterequal(a,g)){
b=(pow(g,c))-(asin(f));
a=(log(b))*(sin(e));
g=(cos(e))+(fmin(a,f));
b=(asin(d))/(acos(b));
e=(fmin(d,c))+(log(c));
}
else{
f=asin(c);
b=fmax(c,g);
d=log10(c);
}
}