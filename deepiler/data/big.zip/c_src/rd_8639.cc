#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=cos(g);
b=fmax(e,b);
e=fmax(c,c);
b=floor(h);
h=fdim(d,b);
while(isless(f,d)){
g=log10(b);
d=(ceil(c))*(fmax(g,f));
}
while(isless(d,f)){
g=exp(c);
b=(tan(c))*(atan(f));
c=fmax(b,e);
}
}