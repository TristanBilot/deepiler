#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=(asin(b))-(tan(d));
d=(atan(a))+(fmax(e,d));
d=fmax(e,b);
while(isgreaterequal(e,d)){
e=(ceil(e))*(ceil(a));
a=fdim(d,d);
e=(pow(a,e))*(fmin(d,e));
b=asin(c);
}
b=tan(c);
d=(pow(c,c))/(pow(d,e));
e=(sqrt(e))/(fmin(b,a));
}