#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(atan2(d,e))+(atan2(c,b));
e=(ceil(b))+(pow(d,e));
while(isless(c,e)){
e=log(c);
a=fmax(e,e);
}
while(islessequal(d,b)){
d=tan(b);
c=(log(e))/(exp(d));
c=exp(b);
a=fmin(a,e);
}
}