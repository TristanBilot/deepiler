#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=sin(a);
c=(pow(a,a))+(atan2(c,b));
d=(atan2(d,b))*(exp(b));
c=atan(e);
e=fmax(d,a);
d=(ceil(d))/(atan2(e,b));
d=(log(d))+(atan2(d,d));
b=(fmax(c,a))*(tan(a));
b=(fmin(a,e))-(cos(c));
}