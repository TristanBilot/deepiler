#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(tan(e))+(log(b));
c=(fdim(b,e))*(tan(d));
while(isless(a,e)){
e=cos(c);
a=atan2(b,a);
d=(log10(b))/(log(a));
c=(fmax(e,c))+(asin(b));
d=fmin(c,d);
}
a=(tan(a))*(fdim(a,a));
d=exp(c);
b=asin(e);
e=asin(e);
e=pow(a,e);
}