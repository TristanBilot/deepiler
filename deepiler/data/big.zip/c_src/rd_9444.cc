#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=cos(a);
a=(exp(c))-(atan2(h,e));
a=(floor(f))+(acos(c));
g=asin(f);
if(islessequal(f,c)){
f=(fdim(h,a))+(atan(e));
g=sin(b);
a=fmin(c,h);
}
g=sin(d);
b=(ceil(h))*(tan(d));
g=(sqrt(g))*(cos(b));
f=(sin(a))*(cos(h));
f=fdim(g,e);
}