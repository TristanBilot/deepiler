#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=(fmax(b,d))+(log(b));
a=fdim(e,f);
e=(exp(e))*(fmin(f,e));
b=floor(f);
while(islessequal(e,a)){
c=asin(d);
b=ceil(e);
c=pow(e,c);
e=cos(a);
a=(log10(d))/(log10(c));
}
}