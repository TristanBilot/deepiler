#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(acos(a))+(pow(a,c));
c=(pow(a,d))+(fdim(d,d));
a=atan(a);
b=(log10(e))+(fdim(d,a));
a=fmax(a,e);
while(isless(b,e)){
c=cos(c);
d=(tan(c))-(tan(c));
c=(tan(a))-(fmax(e,b));
}
b=(pow(b,e))/(pow(d,a));
e=(fmax(e,c))+(sin(c));
}