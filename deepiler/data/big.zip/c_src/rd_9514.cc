#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=atan2(g,e);
e=fmax(d,c);
h=acos(e);
d=(atan2(d,b))/(atan2(f,e));
a=fmin(g,a);
if(islessgreater(e,f)){
h=(atan(h))/(atan2(h,a));
e=(fmin(c,b))/(tan(c));
h=(log(h))/(pow(c,h));
b=(pow(a,c))-(fmin(g,d));
}
else{
d=tan(e);
d=(atan2(a,b))-(tan(a));
g=atan2(c,f);
c=(fmin(b,a))-(floor(b));
g=asin(d);
}
if(islessgreater(a,b)){
f=(cos(h))-(pow(f,a));
d=(sqrt(a))/(exp(g));
c=(fdim(c,f))-(fmax(d,h));
}
else{
g=(acos(d))+(fmin(c,h));
b=(pow(g,a))/(tan(c));
}
}