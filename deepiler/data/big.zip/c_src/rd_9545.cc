#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=fmin(a,c);
e=ceil(b);
d=fmax(d,d);
d=(cos(a))-(exp(c));
c=fmin(e,a);
a=(pow(c,b))-(fdim(b,d));
b=fmin(c,d);
}