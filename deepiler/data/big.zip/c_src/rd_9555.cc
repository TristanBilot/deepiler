#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=floor(d);
e=floor(b);
c=exp(d);
a=(cos(b))*(fmax(d,a));
c=tan(b);
c=(fmax(c,c))*(fmin(c,a));
while(isless(a,b)){
c=(fmax(d,a))+(acos(b));
d=(sqrt(c))+(atan2(e,c));
}
}