#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(fdim(b,d))*(log(e));
a=(acos(d))*(floor(c));
d=atan2(b,a);
c=(sqrt(b))*(fdim(e,c));
e=(fmax(d,e))*(fmin(c,d));
d=acos(b);
e=sin(e);
e=ceil(d);
b=log10(a);
d=fmax(b,b);
}