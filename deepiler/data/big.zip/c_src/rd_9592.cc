#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=sin(b);
g=(fmin(b,a))/(fmin(g,a));
a=atan2(c,b);
e=log(e);
while(islessequal(a,g)){
c=atan2(g,d);
f=log(b);
e=pow(c,e);
c=(pow(e,e))+(tan(b));
}
if(isgreaterequal(d,g)){
c=fdim(e,d);
c=atan2(a,g);
c=fdim(f,d);
b=log10(a);
d=fmax(e,a);
}
else{
b=(atan2(a,g))+(atan2(b,e));
a=(floor(g))+(fmin(a,a));
g=(fdim(c,f))*(log10(d));
}
}