#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=(fmin(g,b))*(fmax(d,e));
e=fmin(b,a);
d=fmin(g,e);
f=fmax(h,f);
h=atan(e);
e=fdim(c,d);
e=(atan2(a,b))-(atan(c));
while(islessgreater(d,h)){
a=acos(b);
h=(pow(c,e))/(cos(g));
}
}