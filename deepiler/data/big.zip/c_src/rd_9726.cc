#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=pow(c,a);
b=(atan2(f,e))*(exp(d));
b=fmax(b,d);
e=(fmax(c,b))*(cos(e));
c=(fmax(c,c))/(floor(d));
if(islessequal(b,e)){
d=cos(f);
a=asin(e);
a=sqrt(d);
}
while(isgreaterequal(a,c)){
f=(ceil(b))*(atan2(b,b));
f=sqrt(f);
b=(atan2(c,c))*(fmin(a,a));
e=sin(e);
c=fmin(c,d);
}
}