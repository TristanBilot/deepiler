#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(atan2(a,c))/(ceil(d));
d=ceil(b);
d=fdim(a,e);
a=(fmax(d,b))*(atan(a));
b=(fdim(a,d))-(atan2(b,a));
d=floor(c);
b=fdim(a,d);
a=(log(d))*(fdim(e,d));
d=(acos(a))-(pow(c,b));
d=fmin(e,d);
e=(atan2(e,a))+(floor(c));
c=(pow(a,b))*(fmax(c,b));
}