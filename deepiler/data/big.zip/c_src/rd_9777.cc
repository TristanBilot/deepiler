#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=(fmax(c,f))/(log10(c));
c=atan2(a,d);
while(isless(e,d)){
c=fmin(d,b);
f=(pow(d,a))*(log10(b));
}
e=fmin(b,e);
a=fmin(f,e);
a=fmin(e,b);
e=fmax(b,f);
}