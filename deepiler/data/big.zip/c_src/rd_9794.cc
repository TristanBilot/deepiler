#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
a=floor(f);
c=(fmax(f,h))*(tan(f));
h=(fmax(b,b))*(sin(e));
h=exp(e);
g=exp(d);
while(isless(e,f)){
d=fdim(a,b);
e=atan(d);
d=(pow(b,d))+(sin(h));
}
if(isgreaterequal(h,h)){
a=(atan2(f,a))/(fdim(h,g));
f=fmax(b,h);
}
}