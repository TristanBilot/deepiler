#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=(atan2(c,e))/(log(h));
c=fdim(f,b);
g=sqrt(d);
c=asin(c);
f=asin(g);
h=(asin(d))*(fmin(e,c));
e=asin(f);
g=(acos(e))/(tan(d));
a=(log(d))-(atan2(g,b));
d=fmin(f,a);
if(islessequal(g,e)){
d=(fmin(f,c))-(fmax(g,b));
b=fmax(f,h);
e=atan2(f,d);
a=(fmin(a,f))*(fdim(g,c));
a=(fmin(a,g))/(fmin(h,a));
}
else{
g=fmin(a,b);
b=fmin(h,f);
a=(pow(h,h))+(atan2(h,e));
b=floor(h);
}
}