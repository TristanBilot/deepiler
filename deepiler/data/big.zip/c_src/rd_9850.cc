#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=atan2(b,c);
c=tan(e);
f=(floor(a))-(pow(d,a));
g=log10(c);
if(isless(g,d)){
f=sqrt(g);
g=fdim(g,g);
f=(atan(e))/(ceil(a));
d=fmax(c,d);
}
b=atan2(c,g);
f=pow(a,a);
a=atan2(d,b);
d=fdim(f,c);
}