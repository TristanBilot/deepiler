#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=(pow(f,a))*(sin(g));
e=(pow(c,a))*(pow(b,e));
g=(atan2(e,g))+(cos(a));
while(isless(e,d)){
c=ceil(c);
c=fmin(a,e);
g=(log(f))+(fmin(b,a));
}
c=(fmin(e,f))*(fmin(g,c));
g=(acos(d))*(log10(c));
}