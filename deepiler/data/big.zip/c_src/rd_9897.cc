#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=pow(a,d);
c=ceil(f);
while(isgreaterequal(b,e)){
d=(acos(c))-(fmax(a,c));
b=(fdim(e,b))*(fmin(e,b));
d=(log(a))/(fdim(e,a));
}
f=(fmax(b,e))+(atan(a));
e=log(a);
d=(sqrt(d))+(cos(c));
}