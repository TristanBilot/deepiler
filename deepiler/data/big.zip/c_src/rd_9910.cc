#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=(floor(c))+(sin(f));
d=(fmax(d,c))*(pow(d,e));
f=floor(b);
c=pow(d,b);
while(isless(a,f)){
b=(pow(d,a))*(fdim(e,e));
e=cos(d);
f=(sin(a))-(pow(c,f));
}
if(isgreaterequal(f,c)){
a=(ceil(d))*(fmax(e,f));
c=fmax(a,b);
f=sqrt(f);
e=(atan(c))-(fmin(e,e));
}
else{
c=(floor(d))*(log10(c));
f=(tan(a))+(fmax(d,d));
d=(exp(a))-(atan2(b,d));
}
}