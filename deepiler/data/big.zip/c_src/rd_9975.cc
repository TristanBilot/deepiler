#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=log10(e);
d=pow(d,d);
h=exp(b);
e=(acos(h))/(fmin(d,g));
b=(tan(f))+(log(a));
g=fmax(d,e);
a=(log10(e))-(fmax(e,g));
if(isgreaterequal(d,c)){
a=(fmax(a,c))+(pow(g,c));
a=pow(h,g);
f=(cos(a))*(log(h));
}
}