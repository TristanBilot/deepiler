#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
b=(fmin(c,h))-(atan(g));
b=fmax(d,f);
g=tan(c);
e=pow(h,f);
g=(fmin(e,d))*(pow(b,e));
f=fmax(g,d);
h=(sin(f))-(atan(b));
h=(sin(e))*(exp(b));
h=(fmin(c,g))+(fmin(f,d));
while(islessequal(h,a)){
e=exp(f);
h=atan(d);
e=(pow(h,h))/(exp(a));
g=fdim(e,g);
b=(fdim(e,f))+(log(f));
}
}