#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=cos(e);
f=(exp(e))+(tan(b));
f=exp(a);
d=(log10(e))/(asin(c));
b=(fmin(f,c))+(exp(g));
g=(fmax(d,b))-(fdim(e,c));
f=(ceil(f))*(sqrt(g));
}