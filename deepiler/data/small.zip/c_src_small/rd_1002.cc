#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=(exp(d))-(atan(e));
g=(fmin(d,e))*(fmin(b,g));
d=(pow(d,e))*(fdim(d,d));
f=(log10(e))*(pow(b,d));
d=pow(c,b);
while(isless(e,b)){
c=(fmin(c,d))*(atan2(f,a));
e=(fdim(b,b))/(exp(c));
d=(sin(a))-(floor(d));
a=(fmax(g,d))*(atan(e));
b=(atan(g))/(atan(a));
}
b=(log10(c))/(log10(f));
g=log10(c);
}