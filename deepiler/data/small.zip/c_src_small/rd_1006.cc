#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=(atan2(b,a))+(sin(a));
b=(pow(d,d))+(fdim(h,f));
f=(exp(e))+(ceil(c));
c=(pow(h,c))-(log10(g));
b=ceil(c);
d=(sqrt(e))/(floor(d));
d=pow(d,d);
c=(fmax(h,f))+(fmax(a,h));
e=fmin(d,g);
h=(fdim(h,g))/(fmax(c,d));
c=atan2(d,b);
b=(fdim(d,c))*(atan2(b,b));
c=(fmax(c,d))-(fmin(b,h));
e=atan(d);
}