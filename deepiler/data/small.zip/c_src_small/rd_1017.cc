#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=(fmin(c,e))/(tan(b));
b=(fdim(c,e))-(fmax(d,f));
d=fmax(c,a);
f=(exp(a))*(acos(b));
if(islessequal(d,c)){
g=(fdim(b,b))+(fmin(a,c));
c=(tan(a))-(log(b));
}
e=(pow(a,d))-(fmax(a,c));
c=pow(f,a);
c=(fdim(a,e))*(fmin(d,f));
}