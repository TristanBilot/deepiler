#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=log10(e);
d=fmin(e,b);
b=(cos(e))/(pow(a,d));
while(isgreaterequal(b,c)){
c=(log10(d))+(cos(a));
f=pow(f,f);
c=atan(b);
a=(sin(c))+(pow(e,d));
f=fdim(b,a);
}
if(isless(b,d)){
a=(tan(a))/(fmax(f,f));
c=fdim(b,c);
b=(fdim(c,d))+(acos(e));
c=pow(e,b);
}
else{
e=(cos(b))*(fmax(e,e));
e=(fdim(a,d))+(fmin(e,a));
e=tan(e);
a=(log10(f))+(fdim(e,d));
}
}