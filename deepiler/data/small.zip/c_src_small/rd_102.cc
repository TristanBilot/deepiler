#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=(fmin(c,e))-(fdim(b,f));
c=floor(d);
if(islessequal(f,c)){
d=fdim(f,b);
d=sin(c);
}
if(isgreaterequal(e,b)){
b=(fdim(d,c))*(pow(c,a));
a=(fmax(f,d))/(pow(e,e));
c=acos(a);
}
else{
c=log10(c);
b=atan(c);
}
}