#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=fdim(c,b);
a=(asin(d))/(cos(c));
if(isless(a,d)){
a=(acos(c))+(fdim(a,c));
d=(fmax(a,e))*(sin(a));
a=(asin(d))+(exp(e));
}
else{
e=(fmin(c,c))+(fdim(d,e));
d=(tan(e))+(sqrt(a));
}
while(isless(b,e)){
c=(floor(c))+(fmin(e,c));
e=pow(b,b);
e=tan(b);
b=(sin(e))-(fdim(e,b));
d=(fmin(a,a))+(atan2(d,b));
}
}