#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=(sqrt(c))/(atan2(a,a));
c=log10(b);
c=fmax(a,a);
d=(exp(a))/(fmax(b,d));
a=(cos(e))*(fdim(b,d));
while(isgreaterequal(e,b)){
c=pow(b,c);
d=(atan2(a,e))*(atan(a));
}
if(isgreaterequal(d,c)){
d=pow(c,d);
e=fdim(c,b);
e=atan(e);
c=(fmin(b,b))+(cos(d));
b=log10(b);
}
else{
d=(atan(a))-(asin(e));
e=(cos(b))*(acos(c));
c=fmin(e,e);
d=floor(c);
}
}