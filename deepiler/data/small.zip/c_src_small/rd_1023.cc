#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=log10(c);
a=tan(e);
a=fmax(e,b);
if(isless(d,b)){
b=log10(e);
b=fdim(b,a);
a=pow(b,b);
}
if(isgreaterequal(b,e)){
e=(fmax(c,c))*(atan2(d,c));
c=sin(b);
b=fmin(c,b);
}
}