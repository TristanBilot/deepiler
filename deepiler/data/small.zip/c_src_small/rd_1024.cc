#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=pow(g,a);
a=acos(h);
b=atan(f);
g=pow(d,h);
b=acos(a);
if(isless(f,h)){
f=(fdim(d,e))-(sin(e));
d=(floor(g))*(log10(f));
e=log(g);
e=fdim(c,c);
}
else{
h=(acos(a))-(atan2(g,a));
b=fdim(d,f);
a=(fdim(b,a))+(pow(h,e));
f=(atan(a))-(pow(a,e));
e=asin(a);
}
c=(log10(g))+(sin(h));
c=fmax(a,c);
a=(fmax(h,e))/(pow(b,h));
c=asin(c);
g=pow(f,f);
}