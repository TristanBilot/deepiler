#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(tan(d))-(exp(a));
e=log(e);
while(islessgreater(c,b)){
c=(ceil(c))/(cos(d));
d=exp(c);
}
e=(atan(c))*(log(e));
e=fdim(c,e);
b=cos(a);
b=fdim(e,d);
}