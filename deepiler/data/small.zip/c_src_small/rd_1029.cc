#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(fdim(e,b))*(atan2(e,b));
e=log(d);
b=(ceil(e))+(cos(b));
f=(atan2(a,a))+(pow(a,b));
e=tan(c);
c=atan(b);
f=tan(e);
c=(fmin(d,e))-(log(f));
e=(asin(f))*(cos(f));
b=(fmax(e,b))+(fdim(a,f));
c=fdim(e,c);
d=(asin(b))+(sqrt(f));
}