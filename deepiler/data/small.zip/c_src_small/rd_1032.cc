#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=fmin(a,e);
a=(acos(f))/(pow(d,c));
f=(log10(f))+(fmin(c,a));
f=(log10(e))+(exp(f));
e=sqrt(b);
if(islessequal(b,f)){
a=(sin(e))+(sin(a));
d=(fmin(a,e))-(fmax(f,e));
}
else{
a=cos(b);
d=(ceil(a))-(cos(f));
}
c=cos(e);
b=ceil(e);
e=(floor(d))-(pow(d,f));
}