#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=(asin(a))+(tan(a));
a=fmin(d,g);
a=(fdim(g,d))+(cos(b));
a=(log10(d))+(log10(b));
e=pow(a,c);
e=sqrt(d);
c=(atan2(b,e))-(cos(d));
c=(log(d))+(sin(a));
f=sin(d);
g=(pow(a,g))/(pow(d,d));
c=fmin(c,b);
g=log10(d);
}