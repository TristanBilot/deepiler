#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(fdim(a,c))+(fmin(b,d));
c=(asin(a))*(floor(b));
c=(fmin(d,e))*(fmax(a,e));
d=fmax(e,e);
while(isless(a,e)){
c=cos(e);
c=(atan2(c,c))/(atan2(d,d));
c=log10(c);
d=(atan2(d,c))*(log10(a));
e=fdim(c,c);
}
}