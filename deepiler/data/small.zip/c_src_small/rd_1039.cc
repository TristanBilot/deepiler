#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
c=(fmax(d,g))+(log(a));
e=(fdim(e,a))/(pow(f,h));
e=(tan(d))*(log(f));
h=log(d);
if(isgreaterequal(c,c)){
f=fmax(a,a);
c=(fmin(g,h))*(pow(b,c));
e=fmax(d,b);
c=acos(d);
c=(fmin(h,g))+(fdim(d,c));
}
else{
f=fdim(d,c);
h=fdim(c,h);
}
if(isgreaterequal(b,b)){
f=sin(e);
c=exp(e);
d=pow(a,b);
e=(atan2(e,g))+(fmax(d,b));
}
}