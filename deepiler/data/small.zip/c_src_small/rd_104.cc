#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=log10(b);
e=fmax(e,e);
h=pow(b,a);
g=atan2(f,f);
d=(atan2(c,d))*(tan(h));
h=exp(f);
f=(log10(a))/(atan2(f,c));
h=(fmin(h,h))*(acos(f));
h=(log(h))-(fdim(a,b));
while(islessgreater(b,d)){
b=(log(b))/(asin(a));
c=fmin(b,d);
c=fdim(a,c);
d=pow(c,h);
}
}