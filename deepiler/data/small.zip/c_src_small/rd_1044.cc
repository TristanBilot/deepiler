#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=(atan2(d,g))-(cos(b));
d=(exp(h))*(cos(f));
a=(exp(e))+(log(a));
f=(fdim(a,a))*(tan(h));
if(islessgreater(f,g)){
f=(atan(f))*(fmax(g,f));
e=sqrt(b);
d=pow(h,a);
c=floor(h);
}
h=(atan2(f,g))/(pow(g,b));
c=asin(g);
b=(fmin(a,e))/(atan2(h,a));
}