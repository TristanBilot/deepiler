#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=fmin(c,b);
e=pow(a,f);
while(isless(b,a)){
e=log(d);
e=(log10(g))-(cos(g));
e=(fmax(e,g))*(pow(e,d));
f=(sqrt(d))/(fmax(g,a));
g=(floor(d))/(log10(e));
}
while(isgreaterequal(f,f)){
g=exp(c);
d=(sqrt(g))-(atan2(e,c));
}
}