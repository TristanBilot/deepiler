#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=atan2(a,d);
c=floor(a);
c=(asin(b))-(sqrt(a));
f=fmin(f,g);
d=sin(g);
b=atan2(a,a);
b=tan(g);
b=fmin(d,f);
e=(atan2(e,c))-(asin(a));
}