#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=pow(d,e);
f=(cos(d))*(tan(f));
f=(fdim(a,b))+(fdim(b,f));
while(isgreaterequal(a,f)){
d=(sqrt(e))+(fmax(f,c));
e=exp(b);
}
f=pow(d,f);
b=atan2(b,b);
c=(pow(b,a))*(exp(f));
a=asin(e);
d=log(a);
}