#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=tan(a);
c=(log10(b))-(acos(e));
while(islessequal(e,a)){
b=(pow(c,f))*(tan(c));
a=exp(e);
e=(fmin(d,a))/(log(e));
d=(fmax(b,b))/(exp(d));
e=atan(a);
}
while(islessgreater(d,a)){
f=floor(b);
b=fmin(d,f);
c=pow(e,a);
}
}