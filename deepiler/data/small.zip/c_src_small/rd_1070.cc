#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=(atan(e))+(fdim(d,e));
f=log(b);
f=(fdim(c,b))-(fmax(d,a));
e=log10(a);
e=ceil(b);
if(islessgreater(d,e)){
b=(atan2(e,e))+(pow(a,e));
c=(fmax(b,b))/(asin(e));
a=fmin(c,d);
f=(pow(a,d))*(fdim(d,f));
}
else{
e=(atan2(b,a))+(floor(f));
b=fmin(f,a);
c=(fdim(a,a))+(atan2(a,c));
}
f=pow(b,c);
d=(asin(e))-(fdim(b,f));
c=floor(e);
}