#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=asin(e);
b=asin(d);
d=(floor(c))+(fmin(c,e));
c=(log10(c))/(log10(a));
a=(log10(c))*(atan2(a,c));
b=(fdim(c,b))-(fmax(a,e));
c=(fmin(b,a))*(atan(a));
e=fmin(b,a);
a=exp(b);
if(islessequal(c,d)){
a=asin(a);
e=fdim(a,b);
}
else{
d=floor(b);
d=(pow(a,c))/(log(d));
d=(tan(e))*(log10(a));
}
}