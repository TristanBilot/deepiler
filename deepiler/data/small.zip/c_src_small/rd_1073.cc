#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=tan(b);
d=(atan2(a,f))*(pow(b,b));
if(isless(f,a)){
e=(fdim(d,b))*(fmax(e,c));
c=(fmin(d,c))*(atan2(b,c));
b=(log10(a))-(log(b));
b=fmin(a,d);
}
if(isgreaterequal(b,e)){
f=fmax(f,a);
e=fmin(a,b);
f=sqrt(b);
d=(log(f))-(fmin(f,f));
f=tan(a);
}
}