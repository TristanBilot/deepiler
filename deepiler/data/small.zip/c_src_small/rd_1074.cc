#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
b=(fmax(c,b))+(fmin(d,e));
c=(pow(d,h))*(atan2(f,h));
while(islessequal(c,g)){
d=(asin(d))*(fmax(e,h));
h=log10(b);
d=sqrt(d);
}
if(islessequal(g,h)){
a=fmin(b,c);
h=atan2(a,e);
d=sqrt(h);
}
}