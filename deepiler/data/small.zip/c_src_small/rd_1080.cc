#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(sqrt(c))/(atan2(a,e));
f=(sqrt(a))*(log10(a));
e=tan(b);
a=fmin(a,f);
c=tan(f);
while(isgreaterequal(d,b)){
c=fmin(c,e);
b=pow(f,e);
c=(fmax(e,c))+(ceil(e));
f=pow(f,c);
f=(fdim(c,e))-(atan(b));
}
while(isgreaterequal(a,f)){
f=fdim(d,c);
b=(atan(f))/(fmax(d,a));
a=atan2(e,a);
}
}