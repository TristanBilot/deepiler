#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=(asin(e))+(sqrt(e));
d=tan(e);
b=log(f);
f=ceil(g);
a=(pow(c,f))*(tan(f));
c=(log10(g))*(atan(a));
f=(fdim(d,f))/(pow(b,a));
while(islessgreater(c,f)){
a=(log(e))+(sin(e));
g=sin(f);
}
}