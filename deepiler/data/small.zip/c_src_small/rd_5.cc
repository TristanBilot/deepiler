#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=fmax(a,a);
c=fmax(b,c);
e=(acos(a))*(fmin(b,e));
b=pow(b,b);
d=(fmin(e,b))+(fmin(b,a));
e=fdim(d,e);
d=acos(a);
}